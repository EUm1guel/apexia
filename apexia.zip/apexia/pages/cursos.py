import flet as ft
import unicodedata

from api import (
    get_cursos,
    get_favoritos_usuario,
    favoritar_curso,
    desfavoritar_curso
)

from ui.layout import layout


def cursos(page, router, user, alert):

    todos_cursos = []
    favoritos_ids = set()

    def normalizar(texto):
        texto = (texto or "").lower()

        return unicodedata.normalize(
            "NFKD",
            texto
        ).encode(
            "ASCII",
            "ignore"
        ).decode("ASCII")

    pesquisa = ft.TextField(
        label="Pesquisar cursos",
        hint_text="Digite o nome do curso...",
        width=350,
        border_radius=14,
        prefix_icon=ft.Icons.SEARCH
    )

    lista = ft.ListView(
        expand=True,
        spacing=18,
        padding=10
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    status = ft.Text(
        "",
        color="#9ca3af",
        size=13
    )

    # ================= FAVORITOS =================

    def toggle_favorito(curso_id):

        if curso_id in favoritos_ids:

            ok = desfavoritar_curso(
                user["id"],
                curso_id
            )

            if ok:
                favoritos_ids.remove(curso_id)

        else:

            ok = favoritar_curso(
                user["id"],
                curso_id
            )

            if ok:
                favoritos_ids.add(curso_id)

        carregar()

    # ================= CARDS =================

    def info_item(icon, texto):

        return ft.Row(
            [
                ft.Icon(
                    icon,
                    size=16,
                    color="#6366f1"
                ),

                ft.Text(
                    texto,
                    size=12,
                    color="#cbd5e1"
                )
            ],
            spacing=6
        )

    def curso_card(curso):

        curso_id = curso["id"]

        favorito = curso_id in favoritos_ids

        return ft.Container(
            width=355,
            bgcolor="#111827",
            border_radius=22,
            shadow=ft.BoxShadow(
                blur_radius=18,
                color="#00000055",
                offset=ft.Offset(0, 6)
            ),

            content=ft.Column(
                [
                    # IMAGEM
                    ft.Container(
                        border_radius=ft.border_radius.only(
                            top_left=22,
                            top_right=22
                        ),

                        clip_behavior=ft.ClipBehavior.HARD_EDGE,

                        content=ft.Image(
                            src=curso.get("imagem")
                            or "https://placehold.co/600x300",

                            width=355,
                            height=180,
                            fit="cover"
                        )
                    ),

                    # CONTEÚDO
                    ft.Container(
                        padding=16,

                        content=ft.Column(
                            [
                                # TÍTULO
                                ft.Row(
                                    [
                                        ft.Text(
                                            curso.get(
                                                "nome",
                                                "Curso"
                                            ),

                                            size=20,
                                            weight="bold",
                                            color="white",

                                            expand=True
                                        ),

                                        ft.IconButton(
                                            icon=(
                                                ft.Icons.FAVORITE
                                                if favorito
                                                else ft.Icons.FAVORITE_BORDER
                                            ),

                                            icon_color=(
                                                "#ef4444"
                                                if favorito
                                                else "#9ca3af"
                                            ),

                                            on_click=lambda e,
                                            cid=curso_id:
                                            toggle_favorito(cid)
                                        )
                                    ]
                                ),

                                # DESCRIÇÃO
                                ft.Text(
                                    curso.get("descricao")
                                    or "Sem descrição",

                                    size=13,

                                    color="#9ca3af",

                                    max_lines=3,

                                    overflow=ft.TextOverflow.ELLIPSIS
                                ),

                                ft.Divider(),

                                # INFO
                                info_item(
                                    ft.Icons.SCHEDULE,
                                    f"Carga horária: "
                                    f"{curso.get('carga_horaria') or 'N/A'}"
                                ),

                                info_item(
                                    ft.Icons.MENU_BOOK,
                                    curso.get(
                                        "disciplinas",
                                        "Disciplinas não informadas"
                                    )
                                ),

                                ft.Row(
                                    [
                                        ft.Row(
                                            [
                                                ft.Icon(
                                                    ft.Icons.PEOPLE,
                                                    size=16,
                                                    color="#6366f1"
                                                ),

                                                ft.Text(
                                                    str(
                                                        curso.get(
                                                            "inscritos",
                                                            0
                                                        )
                                                    ),

                                                    size=12,
                                                    color="#cbd5e1"
                                                )
                                            ],
                                            spacing=4
                                        ),

                                        ft.Row(
                                            [
                                                ft.Icon(
                                                    ft.Icons.FAVORITE,
                                                    size=16,
                                                    color="#ef4444"
                                                ),

                                                ft.Text(
                                                    str(
                                                        curso.get(
                                                            "favoritos",
                                                            0
                                                        )
                                                    ),

                                                    size=12,
                                                    color="#cbd5e1"
                                                )
                                            ],
                                            spacing=4
                                        )
                                    ],

                                    spacing=14
                                ),

                                # BOTÕES
                                ft.Row(
                                    [
                                        ft.ElevatedButton(
                                            "Participar",

                                            bgcolor="#6366f1",

                                            color="white",

                                            icon=ft.Icons.SCHOOL,

                                            on_click=lambda e,
                                            cid=curso_id:
                                            router["ir_inscricao"](cid)
                                        ),

                                        ft.OutlinedButton(
                                            "Avaliar",

                                            icon=ft.Icons.STAR,

                                            on_click=lambda e,
                                            cid=curso_id:
                                            router["abrir_avaliacoes"](cid)
                                        ),
                                    ],

                                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                                )
                            ],

                            spacing=12
                        )
                    )
                ],

                spacing=0
            )
        )

    # ================= RENDER =================

    def renderizar(lista_cursos):

        lista.controls.clear()

        if not lista_cursos:

            lista.controls.append(
                ft.Container(
                    padding=30,
                    bgcolor="#111827",
                    border_radius=20,

                    content=ft.Column(
                        [
                            ft.Icon(
                                ft.Icons.SEARCH_OFF,
                                size=55,
                                color="#6366f1"
                            ),

                            ft.Text(
                                "Nenhum curso encontrado",
                                size=20,
                                weight="bold",
                                color="white"
                            ),

                            ft.Text(
                                "Tente pesquisar outro termo.",
                                size=13,
                                color="#9ca3af"
                            )
                        ],

                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,

                        spacing=12
                    )
                )
            )

        else:

            for curso in lista_cursos:
                lista.controls.append(
                    curso_card(curso)
                )

        page.update()

    # ================= PESQUISA =================

    def filtrar(e=None):

        termo = normalizar(
            pesquisa.value
        )

        if not termo:
            renderizar(todos_cursos)
            return

        filtrados = [
            c for c in todos_cursos

            if termo in normalizar(c.get("nome"))
            or termo in normalizar(c.get("descricao"))
            or termo in normalizar(c.get("disciplinas"))
        ]

        renderizar(filtrados)

    pesquisa.on_change = filtrar

    # ================= LOAD =================

    def carregar():

        nonlocal todos_cursos
        nonlocal favoritos_ids

        lista.controls.clear()

        loading.visible = True

        status.value = ""

        page.update()

        try:

            cursos_data = get_cursos()

            favoritos_data = get_favoritos_usuario(
                user["id"]
            )

            favoritos_ids = {
                f["curso_id"]
                for f in favoritos_data
            }

            todos_cursos = (
                cursos_data
                if isinstance(cursos_data, list)
                else []
            )

            loading.visible = False

            if not todos_cursos:

                status.value = (
                    "Nenhum curso publicado"
                )

                renderizar([])

            else:

                status.value = (
                    f"{len(todos_cursos)} curso(s)"
                )

                renderizar(todos_cursos)

        except Exception as erro:

            loading.visible = False

            status.value = (
                "Erro ao carregar cursos"
            )

            lista.controls.append(
                ft.Text(
                    str(erro),
                    color="#ef4444"
                )
            )

        page.update()

    carregar()

    # ================= HEADER =================

    header = ft.Row(
        [
            ft.Column(
                [
                    ft.Text(
                        "🔥 Cursos populares",
                        size=28,
                        weight="bold",
                        color="white"
                    ),

                    ft.Text(
                        "Explore os cursos mais acessados da plataforma",
                        size=12,
                        color="#9ca3af"
                    )
                ],
                spacing=2
            ),

            ft.IconButton(
                icon=ft.Icons.REFRESH,

                icon_color="#6366f1",

                tooltip="Atualizar",

                on_click=lambda e:
                carregar()
            )
        ],

        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
    )

    content = ft.Column(
        [
            header,

            pesquisa,

            ft.Row(
                [loading],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            status,

            lista
        ],

        expand=True,

        spacing=14
    )

    return layout(
        page,
        content,
        router
    )