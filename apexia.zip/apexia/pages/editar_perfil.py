import flet as ft
from api import update_user
from ui.layout import layout


def editar_perfil(page, router, user, alert):

    nome = ft.TextField(
        label="Atualizar nome de usuário",
        value=user.get("nome", ""),
        width=330,
        border_radius=12,
        prefix_icon=ft.Icons.PERSON
    )

    bio = ft.TextField(
        label="Adicionar bio",
        value=user.get("bio", ""),
        width=330,
        border_radius=12,
        multiline=True,
        min_lines=3,
        max_lines=4,
        prefix_icon=ft.Icons.EDIT
    )

    foto = ft.TextField(
        label="URL da foto de perfil",
        value=user.get("foto", ""),
        width=330,
        border_radius=12,
        prefix_icon=ft.Icons.IMAGE
    )

    status = ft.Text("", color="#ef4444", size=12)

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    preview = ft.Image(
        src=user.get("foto") or "https://placehold.co/120",
        width=125,
        height=125,
        fit="cover",
        border_radius=70
    )

    btn_salvar = ft.ElevatedButton(
        "Salvar alterações",
        width=330,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.SAVE
    )

    def atualizar_preview(e=None):
        preview.src = foto.value or "https://placehold.co/120"
        page.update()

    foto.on_change = atualizar_preview

    def set_loading(state):
        loading.visible = state
        btn_salvar.disabled = state
        btn_salvar.text = "Salvando..." if state else "Salvar alterações"
        page.update()

    def salvar(e=None):
        status.value = ""

        nome_valor = (nome.value or "").strip()
        bio_valor = (bio.value or "").strip()
        foto_valor = (foto.value or "").strip()

        if not nome_valor:
            status.value = "Digite um nome de usuário"
            page.update()
            return

        set_loading(True)

        try:
            ok = update_user(
                user["id"],
                nome_valor,
                foto_valor,
                bio_valor
            )

            if ok:
                user["nome"] = nome_valor
                user["bio"] = bio_valor
                user["foto"] = foto_valor

                alert("Perfil atualizado!")
                router["perfil"]()
                return

            status.value = "Erro ao atualizar perfil"

        except Exception:
            status.value = "Erro ao conectar com o servidor"

        set_loading(False)

    btn_salvar.on_click = salvar

    card = ft.Container(
        width=365,
        padding=28,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                ft.Text(
                    "Editar perfil",
                    size=28,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    "Atualize suas informações públicas do perfil.",
                    size=12,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Container(
                    padding=4,
                    border_radius=80,
                    gradient=ft.LinearGradient(
                        colors=["#f97316", "#ec4899", "#6366f1"]
                    ),
                    content=ft.Container(
                        padding=4,
                        border_radius=76,
                        bgcolor="#111827",
                        content=preview
                    )
                ),

                nome,
                bio,
                foto,

                btn_salvar,
                loading,
                status
            ],
            spacing=15,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["perfil"]()
                    ),
                    ft.Text(
                        "Perfil",
                        size=26,
                        weight="bold",
                        color="white"
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            card,

            ft.OutlinedButton(
                "Voltar ao perfil",
                width=330,
                icon=ft.Icons.ARROW_BACK,
                on_click=lambda e: router["perfil"]()
            ),
        ],
        spacing=20,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        scroll=ft.ScrollMode.AUTO
    )

    return layout(page, content, router)