import flet as ft
from api import request
from ui.layout import layout


def aulas_page(page, router, user, curso_id, alert):

    lista = ft.Column(
        spacing=14,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    status = ft.Text(
        "",
        color="#9ca3af",
        size=13,
        text_align=ft.TextAlign.CENTER
    )

    def abrir_video(url):
        if not url:
            alert("Aula sem link de vídeo")
            return

        page.launch_url(url)

    def aula_card(aula):
        return ft.Container(
            width=360,
            bgcolor="#111827",
            padding=18,
            border_radius=20,
            shadow=ft.BoxShadow(
                blur_radius=14,
                color="#00000055",
                offset=ft.Offset(0, 5)
            ),
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Container(
                                width=48,
                                height=48,
                                border_radius=14,
                                bgcolor="#1e293b",
                                alignment=ft.Alignment(0, 0),
                                content=ft.Icon(
                                    ft.Icons.PLAY_CIRCLE,
                                    color="#6366f1",
                                    size=30
                                )
                            ),

                            ft.Column(
                                [
                                    ft.Text(
                                        aula.get("titulo", "Aula"),
                                        weight="bold",
                                        size=18,
                                        color="white"
                                    ),

                                    ft.Text(
                                        "Conteúdo do curso",
                                        size=11,
                                        color="#9ca3af"
                                    )
                                ],
                                spacing=2,
                                expand=True
                            )
                        ],
                        spacing=12,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER
                    ),

                    ft.Text(
                        aula.get("descricao") or "Sem descrição",
                        color="#cbd5e1",
                        size=13
                    ),

                    ft.Container(
                        padding=12,
                        border_radius=14,
                        bgcolor="#020617",
                        content=ft.Row(
                            [
                                ft.Icon(
                                    ft.Icons.LINK,
                                    size=17,
                                    color="#6366f1"
                                ),

                                ft.Text(
                                    aula.get("video_url") or "Sem vídeo",
                                    size=11,
                                    color="#9ca3af",
                                    expand=True,
                                    overflow=ft.TextOverflow.ELLIPSIS
                                )
                            ],
                            spacing=8
                        )
                    ),

                    ft.ElevatedButton(
                        "Assistir aula",
                        icon=ft.Icons.PLAY_ARROW,
                        bgcolor="#6366f1",
                        color="white",
                        width=320,
                        on_click=lambda e, url=aula.get("video_url"): abrir_video(url)
                    )
                ],
                spacing=12
            )
        )

    def carregar():
        lista.controls.clear()
        loading.visible = True
        status.value = ""
        page.update()

        try:
            r = request(
                "GET",
                f"aulas?curso_id=eq.{curso_id}&order=criado_em.asc"
            )

            loading.visible = False

            if not r:
                status.value = "Erro ao carregar aulas"
                page.update()
                return

            aulas = r.json()

            if not aulas:
                lista.controls.append(
                    ft.Container(
                        width=360,
                        padding=28,
                        bgcolor="#111827",
                        border_radius=20,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.VIDEO_LIBRARY,
                                    size=52,
                                    color="#6366f1"
                                ),

                                ft.Text(
                                    "Nenhuma aula cadastrada",
                                    size=20,
                                    weight="bold",
                                    color="white"
                                ),

                                ft.Text(
                                    "As aulas deste curso aparecerão aqui.",
                                    size=13,
                                    color="#9ca3af",
                                    text_align=ft.TextAlign.CENTER
                                )
                            ],
                            spacing=12,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        )
                    )
                )
            else:
                for aula in aulas:
                    lista.controls.append(aula_card(aula))

        except Exception as erro:
            loading.visible = False
            status.value = f"Erro: {erro}"

        page.update()

    carregar()

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["cursos"]()
                    ),

                    ft.Column(
                        [
                            ft.Text(
                                "Aulas",
                                size=28,
                                weight="bold",
                                color="white"
                            ),
                            ft.Text(
                                "Assista aos conteúdos do curso",
                                size=12,
                                color="#9ca3af"
                            )
                        ],
                        spacing=2
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            ft.Row(
                [loading],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            status,
            lista
        ],
        spacing=18,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)