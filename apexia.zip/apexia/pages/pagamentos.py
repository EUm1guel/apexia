import flet as ft
from api import request
from ui.layout import layout


def pagamento_page(page, router, user, curso_id, alert):

    status = ft.Text(
        "",
        color="#9ca3af",
        size=13
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_pagar = ft.ElevatedButton(
        "Confirmar pagamento",
        width=320,
        height=48,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.PAYMENTS
    )

    metodo = ft.Dropdown(
        width=320,
        border_radius=12,
        label="Método de pagamento",
        value="pix",
        options=[
            ft.dropdown.Option("pix"),
            ft.dropdown.Option("cartao"),
            ft.dropdown.Option("boleto"),
        ]
    )

    card_numero = ft.TextField(
        label="Número do cartão",
        width=320,
        border_radius=12,
        visible=False,
        keyboard_type=ft.KeyboardType.NUMBER
    )

    card_nome = ft.TextField(
        label="Nome no cartão",
        width=320,
        border_radius=12,
        visible=False
    )

    card_validade = ft.TextField(
        label="Validade",
        width=155,
        border_radius=12,
        visible=False,
        hint_text="12/30"
    )

    card_cvv = ft.TextField(
        label="CVV",
        width=155,
        border_radius=12,
        password=True,
        visible=False,
        keyboard_type=ft.KeyboardType.NUMBER
    )

    def atualizar_metodo(e):

        cartao = metodo.value == "cartao"

        card_numero.visible = cartao
        card_nome.visible = cartao
        card_validade.visible = cartao
        card_cvv.visible = cartao

        page.update()

    metodo.on_change = atualizar_metodo

    def set_loading(state):

        loading.visible = state

        btn_pagar.disabled = state

        btn_pagar.text = (
            "Processando..."
            if state
            else "Confirmar pagamento"
        )

        page.update()

    def pagar(e):

        status.value = ""

        if metodo.value == "cartao":

            if not card_numero.value:
                status.value = "Digite o número do cartão"
                page.update()
                return

            if not card_nome.value:
                status.value = "Digite o nome do cartão"
                page.update()
                return

        set_loading(True)

        try:

            response = request(
                "POST",
                "pagamentos",
                json={
                    "usuario_id": user["id"],
                    "curso_id": curso_id,
                    "valor": 49.90,
                    "status": "pago",
                    "metodo": metodo.value
                }
            )

            if response and response.status_code in [200, 201]:

                alert("Pagamento realizado com sucesso!")

                router["cursos"]()

            else:

                status.value = (
                    "Erro ao processar pagamento"
                )

        except Exception:

            status.value = (
                "Erro ao conectar com servidor"
            )

        set_loading(False)

    btn_pagar.on_click = pagar

    card_pagamento = ft.Container(
        width=360,
        padding=24,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                ft.Container(
                    width=68,
                    height=68,
                    border_radius=20,
                    bgcolor="#1e293b",
                    alignment=ft.Alignment(0, 0),
                    content=ft.Icon(
                        ft.Icons.ACCOUNT_BALANCE_WALLET,
                        size=38,
                        color="#6366f1"
                    )
                ),

                ft.Text(
                    "Pagamento do Curso",
                    size=26,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    "Finalize sua inscrição realizando o pagamento abaixo.",
                    size=12,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Container(
                    width=320,
                    padding=18,
                    border_radius=18,
                    bgcolor="#020617",
                    content=ft.Column(
                        [
                            ft.Row(
                                [
                                    ft.Text(
                                        "Valor",
                                        color="#9ca3af"
                                    ),

                                    ft.Text(
                                        "R$ 49,90",
                                        color="white",
                                        weight="bold",
                                        size=18
                                    )
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                            ),

                            ft.Row(
                                [
                                    ft.Text(
                                        "Status",
                                        color="#9ca3af"
                                    ),

                                    ft.Container(
                                        padding=ft.padding.symmetric(
                                            horizontal=10,
                                            vertical=4
                                        ),
                                        border_radius=20,
                                        bgcolor="#f59e0b22",
                                        content=ft.Text(
                                            "Pendente",
                                            color="#f59e0b",
                                            size=11
                                        )
                                    )
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                            )
                        ]
                    )
                ),

                metodo,

                card_numero,

                card_nome,

                ft.Row(
                    [
                        card_validade,
                        card_cvv
                    ],
                    alignment=ft.MainAxisAlignment.CENTER
                ),

                btn_pagar,

                loading,

                status
            ],
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e:
                        router["cursos"]()
                    ),

                    ft.Text(
                        "Pagamento",
                        size=28,
                        weight="bold",
                        color="white"
                    )
                ]
            ),

            card_pagamento
        ],

        spacing=24,

        scroll=ft.ScrollMode.AUTO,

        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(
        page,
        content,
        router
    )