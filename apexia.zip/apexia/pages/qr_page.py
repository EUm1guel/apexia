import flet as ft
import qrcode
import base64
from io import BytesIO

from api import seguir_usuario
from ui.layout import layout


# =========================
# GERAR QR CODE
# =========================
def gerar_qrcode(user_id):

    valor_qr = f"apexia_user:{user_id}"

    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=4
    )

    qr.add_data(valor_qr)
    qr.make(fit=True)

    img = qr.make_image(
        fill_color="black",
        back_color="white"
    )

    buffer = BytesIO()
    img.save(buffer, format="PNG")

    return base64.b64encode(buffer.getvalue()).decode()


# =========================
# LIMPAR ID
# =========================
def limpar_id(valor):

    valor = (valor or "").strip()

    if valor.startswith("apexia_user:"):
        valor = valor.replace("apexia_user:", "")

    return valor.strip()


# =========================
# PAGE
# =========================
def qr_page(page, router, user, alert):

    user_id = str(user["id"])

    qr_base64 = gerar_qrcode(user_id)

    # =========================
    # INPUT
    # =========================
    input_id = ft.TextField(
        label="ID do usuário para seguir",
        hint_text="Cole o ID aqui",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.PERSON_ADD
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_seguir = ft.ElevatedButton(
        "Seguir usuário",
        width=320,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.PERSON_ADD
    )

    # =========================
    # LOADING
    # =========================
    def set_loading(state):

        loading.visible = state

        btn_seguir.disabled = state

        btn_seguir.text = (
            "Seguindo..."
            if state
            else "Seguir usuário"
        )

        page.update()

    # =========================
    # COPIAR ID
    # =========================
    def copiar_id(e):

        input_id.value = user_id

        alert(
            "ID colocado no campo para copiar manualmente"
        )

        page.update()

    # =========================
    # SEGUIR
    # =========================
    def seguir(e=None):

        status.value = ""

        alvo_id = limpar_id(
            input_id.value
        )

        if not alvo_id:

            status.value = (
                "Digite ou cole o ID do usuário"
            )

            page.update()
            return

        if alvo_id == user_id:

            status.value = (
                "Você não pode seguir a si mesmo"
            )

            page.update()
            return

        set_loading(True)

        try:

            ok = seguir_usuario(
                user_id,
                alvo_id
            )

            if ok:

                alert(
                    "Usuário seguido com sucesso!"
                )

                input_id.value = ""
                status.value = ""

            else:

                status.value = (
                    "Usuário já seguido ou ID inválido"
                )

        except Exception as erro:

            status.value = f"Erro: {erro}"

        set_loading(False)

    btn_seguir.on_click = seguir
    input_id.on_submit = seguir

    # =========================
    # QR CARD
    # =========================
    qr_card = ft.Container(
        width=360,
        padding=24,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=16,
            color="#00000055",
            offset=ft.Offset(0, 5)
        ),
        content=ft.Column(
            [
                ft.Icon(
                    ft.Icons.QR_CODE,
                    size=42,
                    color="#6366f1"
                ),

                ft.Text(
                    "Seu QR Code",
                    size=26,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    (
                        "Compartilhe este QR Code "
                        "ou copie seu ID para outros "
                        "usuários te seguirem."
                    ),
                    size=12,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Container(
                    padding=12,
                    bgcolor="white",
                    border_radius=18,
                    content=ft.Image(
                        src=(
                            f"data:image/png;base64,"
                            f"{qr_base64}"
                        ),
                        width=220,
                        height=220
                    )
                ),

                ft.Container(
                    width=320,
                    padding=ft.padding.symmetric(
                        horizontal=14,
                        vertical=10
                    ),
                    border_radius=14,
                    bgcolor="#020617",
                    content=ft.Row(
                        [
                            ft.Text(
                                f"ID: {user_id}",
                                size=13,
                                color="#cbd5e1",
                                selectable=True,
                                expand=True
                            ),

                            ft.IconButton(
                                icon=ft.Icons.CONTENT_COPY,
                                icon_color="#6366f1",
                                tooltip="Copiar ID",
                                on_click=copiar_id
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    )
                )
            ],
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    # =========================
    # FOLLOW CARD
    # =========================
    seguir_card = ft.Container(
        width=360,
        padding=24,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=16,
            color="#00000055",
            offset=ft.Offset(0, 5)
        ),
        content=ft.Column(
            [
                ft.Text(
                    "Seguir usuário",
                    size=22,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    (
                        "Cole aqui o ID copiado "
                        "para seguir outro usuário."
                    ),
                    size=12,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                input_id,

                btn_seguir,

                loading,

                status
            ],
            spacing=12,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    # =========================
    # CONTENT
    # =========================
    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["profile"]()
                    ),

                    ft.Text(
                        "Conectar usuários",
                        size=26,
                        weight="bold",
                        color="white"
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            qr_card,

            seguir_card
        ],
        spacing=20,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(
        page,
        content,
        router
    )