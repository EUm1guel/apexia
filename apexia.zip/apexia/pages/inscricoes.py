import flet as ft
from api import get_inscricoes, get_cursos
from ui.layout import layout


def inscricoes(page, router, user, alert):

    lista = ft.ListView(
        expand=True,
        spacing=18,
        padding=10
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    status = ft.Text(
        "",
        color="#9ca3af",
        size=13,
        text_align=ft.TextAlign.CENTER
    )

    def card_info(icon, texto):
        return ft.Row(
            [
                ft.Icon(
                    icon,
                    size=17,
                    color="#6366f1"
                ),
                ft.Text(
                    texto,
                    size=12,
                    color="#cbd5e1"
                )
            ],
            spacing=6
        )

    def card_inscricao(curso, insc):
        return ft.Container(
            width=350,
            bgcolor="#111827",
            border_radius=20,
            shadow=ft.BoxShadow(
                blur_radius=14,
                color="#00000055",
                offset=ft.Offset(0, 5)
            ),
            content=ft.Column(
                [
                    ft.Container(
                        border_radius=ft.border_radius.only(
                            top_left=20,
                            top_right=20
                        ),
                        clip_behavior=ft.ClipBehavior.HARD_EDGE,
                        content=ft.Image(
                            src=curso.get("imagem") or "https://placehold.co/350x150",
                            height=150,
                            width=350,
                            fit="cover"
                        )
                    ),

                    ft.Container(
                        padding=16,
                        content=ft.Column(
                            [
                                ft.Text(
                                    curso.get("nome", "Curso"),
                                    size=20,
                                    weight="bold",
                                    color="white"
                                ),

                                ft.Text(
                                    curso.get("descricao") or "Sem descrição",
                                    color="#9ca3af",
                                    size=13,
                                    max_lines=3,
                                    overflow=ft.TextOverflow.ELLIPSIS
                                ),

                                ft.Divider(),

                                card_info(
                                    ft.Icons.BADGE,
                                    f"CPF: {insc.get('cpf') or 'Não informado'}"
                                ),

                                card_info(
                                    ft.Icons.ACCESS_TIME,
                                    f"Horário: {insc.get('horario') or 'Não informado'}"
                                ),

                                card_info(
                                    ft.Icons.CHECK_CIRCLE,
                                    "Inscrição ativa"
                                ),
                            ],
                            spacing=9
                        )
                    )
                ],
                spacing=0
            )
        )

    def carregar():
        lista.controls.clear()
        loading.visible = True
        status.value = ""
        page.update()

        try:
            cursos_data = get_cursos()
            inscricoes_data = get_inscricoes(user["id"])

            loading.visible = False

            if not inscricoes_data:
                status.value = "Você ainda não se inscreveu em cursos"
                lista.controls.append(
                    ft.Container(
                        padding=25,
                        bgcolor="#111827",
                        border_radius=18,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.INBOX,
                                    size=48,
                                    color="#6366f1"
                                ),
                                ft.Text(
                                    "Nenhuma inscrição encontrada",
                                    color="white",
                                    size=18,
                                    weight="bold"
                                ),
                                ft.Text(
                                    "Explore os cursos disponíveis e faça sua primeira inscrição.",
                                    color="#9ca3af",
                                    size=13,
                                    text_align=ft.TextAlign.CENTER
                                ),
                                ft.ElevatedButton(
                                    "Ver cursos",
                                    bgcolor="#6366f1",
                                    color="white",
                                    icon=ft.Icons.SCHOOL,
                                    on_click=lambda e: router["cursos"]()
                                )
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=12
                        )
                    )
                )
            else:
                for item in inscricoes_data:
                    curso = next(
                        (c for c in cursos_data if c["id"] == item["curso_id"]),
                        None
                    )

                    if curso:
                        lista.controls.append(
                            card_inscricao(curso, item)
                        )

        except Exception as erro:
            loading.visible = False
            status.value = f"Erro ao carregar inscrições: {erro}"
            lista.controls.append(
                ft.Text(
                    "Erro ao carregar dados",
                    color="#ef4444"
                )
            )

        page.update()

    carregar()

    header = ft.Row(
        [
            ft.Column(
                [
                    ft.Text(
                        "Minhas Inscrições",
                        size=26,
                        weight="bold",
                        color="white"
                    ),
                    ft.Text(
                        "Acompanhe os cursos em que você se inscreveu",
                        size=12,
                        color="#9ca3af"
                    )
                ],
                spacing=2
            ),

            ft.IconButton(
                icon=ft.Icons.REFRESH,
                icon_color="#6366f1",
                tooltip="Atualizar",
                on_click=lambda e: carregar()
            )
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        vertical_alignment=ft.CrossAxisAlignment.CENTER
    )

    content = ft.Column(
        [
            header,

            ft.Row(
                [loading],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            status,

            lista
        ],
        expand=True,
        spacing=12
    )

    return layout(page, content, router)