import flet as ft
import re
from api import login


def login_view(page, go, set_user):

    email = ft.TextField(
        label="Email",
        hint_text="Digite seu email",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.EMAIL,
        keyboard_type=ft.KeyboardType.EMAIL
    )

    senha = ft.TextField(
        label="Senha",
        hint_text="Digite sua senha",
        password=True,
        can_reveal_password=True,
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.LOCK
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_login = ft.ElevatedButton(
        "Entrar",
        width=320,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.LOGIN
    )

    def email_valido(valor):
        valor = (valor or "").strip()
        return re.match(r"^[^@]+@[^@]+\.[^@]+$", valor)

    def set_loading(state):
        loading.visible = state
        btn_login.disabled = state
        btn_login.text = "Entrando..." if state else "Entrar"
        page.update()

    def fazer_login(e=None):
        status.value = ""

        email_valor = (email.value or "").strip().lower()
        senha_valor = senha.value or ""

        if not email_valido(email_valor):
            status.value = "Digite um email válido"
            page.update()
            return

        if not senha_valor:
            status.value = "Digite sua senha"
            page.update()
            return

        set_loading(True)

        try:
            user = login(email_valor, senha_valor)

            if user:
                set_user(user)
                return

            status.value = "Email ou senha inválidos"

        except Exception:
            status.value = "Erro ao conectar com o servidor"

        set_loading(False)

    email.on_submit = fazer_login
    senha.on_submit = fazer_login
    btn_login.on_click = fazer_login

    card = ft.Container(
        width=365,
        padding=30,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                ft.Container(
                    width=70,
                    height=70,
                    border_radius=22,
                    bgcolor="#1e293b",
                    alignment=ft.Alignment(0, 0),
                    content=ft.Icon(
                        ft.Icons.SCHOOL,
                        size=40,
                        color="#6366f1"
                    )
                ),

                ft.Text(
                    "APEXIA",
                    size=34,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    "Entre na sua conta para continuar aprendendo",
                    size=13,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Divider(),

                email,
                senha,

                btn_login,
                loading,
                status,

                ft.Row(
                    [
                        ft.Text(
                            "Não tem conta?",
                            size=12,
                            color="#9ca3af"
                        ),
                        ft.TextButton(
                            "Criar cadastro",
                            on_click=lambda e: go("/cadastro")
                        )
                    ],
                    alignment=ft.MainAxisAlignment.CENTER
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=14
        )
    )

    return ft.Container(
        content=card,
        alignment=ft.Alignment(0, 0),
        expand=True,
        bgcolor="#0f172a"
    )