import flet as ft
from api import request
from ui.layout import layout


def feed_page(page, router, user, alert):

    lista = ft.Column(
        spacing=18,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    status = ft.Text(
        "",
        color="#9ca3af",
        size=13
    )

    def abrir_comentarios(post_id):
        router["comentarios"](post_id)

    def curtir(btn, likes_text, post):

        likes = post.get("_likes", 0) + 1

        post["_likes"] = likes

        likes_text.value = str(likes)

        btn.icon = ft.Icons.FAVORITE
        btn.icon_color = "#ef4444"

        page.update()

    def card_post(post):

        likes_text = ft.Text(
            str(post.get("_likes", 0)),
            color="#9ca3af",
            size=12
        )

        like_btn = ft.IconButton(
            icon=ft.Icons.FAVORITE_BORDER,
            icon_color="white",
            icon_size=20
        )

        like_btn.on_click = lambda e: curtir(
            like_btn,
            likes_text,
            post
        )

        return ft.Container(
            width=360,
            bgcolor="#111827",
            border_radius=22,
            shadow=ft.BoxShadow(
                blur_radius=16,
                color="#00000055",
                offset=ft.Offset(0, 6)
            ),
            content=ft.Column(
                [
                    # HEADER
                    ft.Container(
                        padding=15,
                        content=ft.Row(
                            [
                                ft.CircleAvatar(
                                    foreground_image_src=post.get(
                                        "foto_usuario"
                                    ) or "https://placehold.co/100",
                                    radius=22
                                ),

                                ft.Column(
                                    [
                                        ft.Text(
                                            post.get(
                                                "nome_usuario",
                                                f"Usuário {post['usuario_id']}"
                                            ),
                                            size=14,
                                            weight="bold",
                                            color="white"
                                        ),

                                        ft.Text(
                                            "Postagem recente",
                                            size=11,
                                            color="#9ca3af"
                                        )
                                    ],
                                    spacing=2
                                ),

                                ft.Icon(
                                    ft.Icons.MORE_VERT,
                                    color="#9ca3af"
                                )
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                        )
                    ),

                    # TEXTO
                    ft.Container(
                        padding=ft.padding.only(
                            left=15,
                            right=15,
                            bottom=10
                        ),
                        content=ft.Text(
                            post.get("texto", ""),
                            color="white",
                            size=14
                        )
                    ),

                    # IMAGEM
                    ft.Container(
                        clip_behavior=ft.ClipBehavior.HARD_EDGE,
                        content=ft.Image(
                            src=post.get("imagem")
                            or "https://placehold.co/600x400",
                            width=360,
                            height=260,
                            fit="cover"
                        )
                    ),

                    # AÇÕES
                    ft.Container(
                        padding=15,
                        content=ft.Row(
                            [
                                ft.Row(
                                    [
                                        like_btn,
                                        likes_text
                                    ],
                                    spacing=0
                                ),

                                ft.TextButton(
                                    "💬 Comentários",
                                    on_click=lambda e,
                                    pid=post["id"]:
                                    abrir_comentarios(pid)
                                ),

                                ft.IconButton(
                                    icon=ft.Icons.SHARE,
                                    icon_color="#9ca3af"
                                )
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                        )
                    )
                ],
                spacing=0
            )
        )

    def carregar():

        lista.controls.clear()

        loading.visible = True

        status.value = ""

        page.update()

        try:

            r = request(
                "GET",
                "posts?order=criado_em.desc"
            )

            loading.visible = False

            if not r:

                status.value = (
                    "Erro ao carregar feed"
                )

                lista.controls.append(
                    ft.Text(
                        "Erro ao carregar posts",
                        color="#ef4444"
                    )
                )

                page.update()
                return

            posts = r.json()

            if not posts:

                lista.controls.append(
                    ft.Container(
                        padding=30,
                        bgcolor="#111827",
                        border_radius=20,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.DYNAMIC_FEED,
                                    size=55,
                                    color="#6366f1"
                                ),

                                ft.Text(
                                    "Nenhum post ainda",
                                    size=20,
                                    weight="bold",
                                    color="white"
                                ),

                                ft.Text(
                                    "Os posts publicados aparecerão aqui.",
                                    size=13,
                                    color="#9ca3af",
                                    text_align=ft.TextAlign.CENTER
                                )
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=12
                        )
                    )
                )

            for post in posts:

                lista.controls.append(
                    card_post(post)
                )

        except Exception as erro:

            loading.visible = False

            status.value = (
                f"Erro: {erro}"
            )

            lista.controls.append(
                ft.Text(
                    "Erro ao carregar feed",
                    color="#ef4444"
                )
            )

        page.update()

    carregar()

    header = ft.Row(
        [
            ft.Column(
                [
                    ft.Text(
                        "Feed",
                        size=30,
                        weight="bold",
                        color="white"
                    ),

                    ft.Text(
                        "Veja publicações da comunidade",
                        size=12,
                        color="#9ca3af"
                    )
                ],
                spacing=2
            ),

            ft.IconButton(
                icon=ft.Icons.REFRESH,
                icon_color="#6366f1",
                tooltip="Atualizar",
                on_click=lambda e: carregar()
            )
        ],

        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
    )

    content = ft.Column(
        [
            header,

            ft.Row(
                [loading],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            status,

            lista
        ],

        spacing=18,

        scroll=ft.ScrollMode.AUTO,

        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(
        page,
        content,
        router
    )