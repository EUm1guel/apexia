import flet as ft
from api import (
    get_inscricoes,
    get_cursos,
    delete_curso,
    get_seguidores,
    get_seguindo
)
from ui.layout import layout


def perfil(page, router, user, alert):

    if "_stories" not in user:
        user["_stories"] = []

    if "_feed" not in user:
        user["_feed"] = []

    stories_data = user["_stories"]
    feed_data = user["_feed"]

    avatar = ft.Image(
        src=user.get("foto") or "https://placehold.co/120",
        width=95,
        height=95,
        fit="cover",
        border_radius=50
    )

    stories_row = ft.Row(
        scroll=ft.ScrollMode.AUTO,
        spacing=12
    )

    feed_grid = ft.GridView(
        runs_count=3,
        max_extent=115,
        child_aspect_ratio=1,
        spacing=4,
        run_spacing=4,
        height=270
    )

    lista_inscritos = ft.Column(spacing=10)
    lista_meus = ft.Column(spacing=10)

    seguidores_count = ft.Text("0", size=16, weight="bold")
    seguindo_count = ft.Text("0", size=16, weight="bold")
    posts_count = ft.Text("0", size=16, weight="bold")

    status = ft.Text(
        color="#9ca3af",
        size=13
    )

    def atualizar(update=True):
        if update:
            page.update()

    def fechar_dialog(e=None):
        if page.dialog:
            page.dialog.open = False
        page.update()

    # ================= STORY =================

    def abrir_story(item):

        legenda = (
            item.get("legenda")
            or item.get("texto")
            or ""
        )

        midia = (
            item.get("midia")
            or item.get("img")
        )

        page.dialog = ft.AlertDialog(
            modal=True,
            bgcolor="#111827",
            title=ft.Text(
                item.get("titulo", "Story"),
                color="white"
            ),
            content=ft.Column(
                [
                    ft.Image(
                        src=midia,
                        width=300,
                        height=420,
                        fit="cover",
                        border_radius=18
                    ),

                    ft.Text(
                        legenda,
                        color="white"
                    )
                ],
                tight=True,
                spacing=10,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER
            ),
            actions=[
                ft.TextButton(
                    "Fechar",
                    on_click=fechar_dialog
                )
            ]
        )

        page.dialog.open = True
        page.update()

    def story_item(titulo, img=None, icon=None, action=None):

        if img:
            centro = ft.Image(
                src=img,
                width=62,
                height=62,
                fit="cover",
                border_radius=35
            )
        else:
            centro = ft.Icon(
                icon,
                color="white",
                size=30
            )

        return ft.Column(
            [
                ft.Container(
                    width=70,
                    height=70,
                    border_radius=40,
                    padding=3,
                    gradient=ft.LinearGradient(
                        colors=[
                            "#f97316",
                            "#ec4899",
                            "#6366f1"
                        ]
                    ),
                    content=ft.Container(
                        border_radius=35,
                        bgcolor="#111827",
                        alignment=ft.Alignment(0, 0),
                        content=centro,
                        on_click=action
                    )
                ),

                ft.Text(
                    titulo,
                    size=11,
                    width=75,
                    text_align=ft.TextAlign.CENTER,
                    overflow=ft.TextOverflow.ELLIPSIS,
                    color="white"
                )
            ],
            spacing=5,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )

    def renderizar_stories(update=True):

        stories_row.controls.clear()

        stories_row.controls.append(
            story_item(
                "Adicionar",
                icon=ft.Icons.ADD,
                action=lambda e: router["adicionar_story"]()
            )
        )

        for item in stories_data:

            stories_row.controls.append(
                story_item(
                    item.get("titulo", "Story"),
                    img=item.get("midia") or item.get("img"),
                    action=lambda e, i=item: abrir_story(i)
                )
            )

        atualizar(update)

    # ================= FEED =================

    post_titulo = ft.TextField(
        label="Título do post",
        width=300
    )

    post_img = ft.TextField(
        label="URL da imagem do post",
        width=300
    )

    post_descricao = ft.TextField(
        label="Descrição",
        width=300,
        multiline=True
    )

    def salvar_post(e):

        if not post_titulo.value:
            alert("Digite o título do post")
            return

        if not post_img.value:
            alert("Coloque a URL da imagem")
            return

        feed_data.append({
            "titulo": post_titulo.value,
            "img": post_img.value,
            "descricao": post_descricao.value,
            "likes": 0
        })

        post_titulo.value = ""
        post_img.value = ""
        post_descricao.value = ""

        fechar_dialog()
        renderizar_feed()

        alert("Post publicado!")

    def abrir_post_dialog(e=None):

        page.dialog = ft.AlertDialog(
            modal=True,
            bgcolor="#111827",
            title=ft.Text(
                "Adicionar Post",
                color="white"
            ),
            content=ft.Column(
                [
                    post_titulo,
                    post_img,
                    post_descricao
                ],
                tight=True,
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancelar",
                    on_click=fechar_dialog
                ),

                ft.ElevatedButton(
                    "Publicar",
                    on_click=salvar_post
                )
            ]
        )

        page.dialog.open = True
        page.update()

    def abrir_post(item):

        page.dialog = ft.AlertDialog(
            modal=True,
            bgcolor="#111827",
            title=ft.Text(
                item["titulo"],
                color="white"
            ),
            content=ft.Column(
                [
                    ft.Image(
                        src=item["img"],
                        width=300,
                        height=300,
                        fit="cover",
                        border_radius=12
                    ),

                    ft.Text(
                        item.get("descricao") or "",
                        color="white"
                    ),

                    ft.Text(
                        f'{item["likes"]} curtidas',
                        weight="bold",
                        color="white"
                    )
                ],
                tight=True,
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Fechar",
                    on_click=fechar_dialog
                )
            ]
        )

        page.dialog.open = True
        page.update()

    def feed_post(item):

        likes_text = ft.Text(
            str(item["likes"]),
            size=12,
            color="white"
        )

        def curtir(e):

            item["likes"] += 1

            likes_text.value = str(item["likes"])

            e.control.icon = ft.Icons.FAVORITE
            e.control.icon_color = "#ef4444"

            page.update()

        return ft.Container(
            bgcolor="#111827",
            border_radius=6,
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            on_click=lambda e, i=item: abrir_post(i),
            content=ft.Stack(
                [
                    ft.Image(
                        src=item["img"],
                        width=115,
                        height=115,
                        fit="cover"
                    ),

                    ft.Container(
                        bgcolor="#00000088",
                        alignment=ft.Alignment(0, 1),
                        padding=4,
                        content=ft.Row(
                            [
                                ft.IconButton(
                                    icon=ft.Icons.FAVORITE_BORDER,
                                    icon_size=16,
                                    icon_color="white",
                                    on_click=curtir
                                ),

                                likes_text
                            ],
                            spacing=0,
                            alignment=ft.MainAxisAlignment.CENTER
                        )
                    )
                ]
            )
        )

    def renderizar_feed(update=True):

        feed_grid.controls.clear()

        for item in feed_data:
            feed_grid.controls.append(feed_post(item))

        posts_count.value = str(len(feed_data))

        atualizar(update)

    # ================= CURSOS =================

    def card_item(titulo, descricao="", action=None):

        controls = [
            ft.Text(
                titulo or "Sem título",
                weight="bold",
                color="white"
            ),

            ft.Text(
                descricao or "Sem descrição",
                size=12,
                color="#9ca3af"
            ),
        ]

        if action:
            controls.append(action)

        return ft.Container(
            width=330,
            bgcolor="#1f2937",
            padding=12,
            border_radius=12,
            content=ft.Column(
                controls,
                spacing=6
            )
        )

    def carregar(update=True):

        lista_inscritos.controls.clear()
        lista_meus.controls.clear()

        try:

            cursos_data = get_cursos()

            inscricoes_data = get_inscricoes(
                user["id"]
            )

            seguidores = get_seguidores(
                user["id"]
            )

            seguindo = get_seguindo(
                user["id"]
            )

            seguidores_count.value = str(
                len(seguidores)
            )

            seguindo_count.value = str(
                len(seguindo)
            )

            if not inscricoes_data:

                lista_inscritos.controls.append(
                    ft.Text(
                        "Você ainda não participa de cursos",
                        color="#9ca3af"
                    )
                )

            for item in inscricoes_data:

                curso = next(
                    (
                        c for c in cursos_data
                        if c["id"] == item["curso_id"]
                    ),
                    None
                )

                if curso:

                    lista_inscritos.controls.append(
                        card_item(
                            curso.get("nome"),
                            curso.get("descricao")
                        )
                    )

            meus = [
                c for c in cursos_data
                if c.get("criador_id") == user["id"]
            ]

            if not meus:

                lista_meus.controls.append(
                    ft.Text(
                        "Você ainda não criou cursos",
                        color="#9ca3af"
                    )
                )

            for curso in meus:

                def excluir(e, cid=curso["id"]):

                    ok = delete_curso(cid)

                    if ok:
                        alert("Curso removido!")
                        carregar()
                    else:
                        alert("Erro ao remover curso")

                lista_meus.controls.append(
                    card_item(
                        curso.get("nome"),
                        curso.get("descricao"),

                        ft.TextButton(
                            "Excluir",
                            on_click=excluir,
                            style=ft.ButtonStyle(
                                color="#ef4444"
                            )
                        )
                    )
                )

        except Exception as erro:

            status.value = (
                f"Erro ao carregar perfil: {erro}"
            )

        atualizar(update)

    # ================= HEADER =================

    header = ft.Container(
        padding=15,
        content=ft.Column(
            [
                ft.Row(
                    [
                        avatar,

                        ft.Row(
                            [
                                ft.Column(
                                    [
                                        posts_count,
                                        ft.Text(
                                            "posts",
                                            size=11,
                                            color="white"
                                        )
                                    ],
                                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                                ),

                                ft.Column(
                                    [
                                        seguidores_count,
                                        ft.Text(
                                            "seguidores",
                                            size=11,
                                            color="white"
                                        )
                                    ],
                                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                                ),

                                ft.Column(
                                    [
                                        seguindo_count,
                                        ft.Text(
                                            "seguindo",
                                            size=11,
                                            color="white"
                                        )
                                    ],
                                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                                ),
                            ],

                            expand=True,

                            alignment=ft.MainAxisAlignment.SPACE_EVENLY
                        )
                    ],

                    vertical_alignment=ft.CrossAxisAlignment.CENTER
                ),

                ft.Text(
                    user.get("nome", ""),
                    weight="bold",
                    size=18,
                    color="white"
                ),

                ft.Text(
                    user.get("email", ""),
                    size=12,
                    color="#9ca3af"
                ),

                ft.Text(
                    user.get(
                        "bio",
                        "Criador de cursos na Apexia"
                    ),
                    size=12,
                    color="white"
                ),

                ft.Row(
                    [
                        ft.ElevatedButton(
                            "Editar perfil",
                            expand=True,
                            bgcolor="#262626",
                            color="white",
                            on_click=lambda e:
                            router["editar_perfil"]()
                        ),

                        ft.ElevatedButton(
                            "Adicionar curso",
                            expand=True,
                            bgcolor="#6366f1",
                            color="white",
                            icon=ft.Icons.ADD,
                            on_click=lambda e:
                            router["criar_curso"]()
                        ),
                    ],
                    spacing=8
                ),

                ft.Row(
                    [
                        ft.ElevatedButton(
                            "Adicionar story",
                            expand=True,
                            bgcolor="#ec4899",
                            color="white",
                            icon=ft.Icons.ADD_A_PHOTO,
                            on_click=lambda e:
                            router["adicionar_story"]()
                        ),

                        ft.ElevatedButton(
                            "Adicionar feed",
                            expand=True,
                            bgcolor="#111827",
                            color="white",
                            icon=ft.Icons.GRID_ON,
                            on_click=abrir_post_dialog
                        ),
                    ],
                    spacing=8
                )
            ],
            spacing=9
        )
    )

    carregar(update=False)

    renderizar_stories(update=False)

    renderizar_feed(update=False)

    content = ft.Column(
        [
            header,

            ft.Container(
                padding=ft.padding.only(
                    left=10,
                    right=10
                ),
                content=stories_row
            ),

            ft.Divider(),

            ft.Row(
                [
                    ft.Icon(
                        ft.Icons.GRID_ON,
                        color="white"
                    ),

                    ft.Text(
                        "Feed",
                        weight="bold",
                        color="white"
                    )
                ],

                alignment=ft.MainAxisAlignment.CENTER
            ),

            feed_grid,

            ft.Row(
                [status],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            ft.Divider(),

            ft.Text(
                "Cursos que você participa",
                size=16,
                weight="bold",
                color="white"
            ),

            lista_inscritos,

            ft.Divider(),

            ft.Text(
                "Meus cursos",
                size=16,
                weight="bold",
                color="white"
            ),

            lista_meus,
        ],

        scroll=ft.ScrollMode.AUTO,
        spacing=14,

        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(
        page,
        content,
        router
    )