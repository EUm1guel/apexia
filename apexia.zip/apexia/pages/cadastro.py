import flet as ft
import re
from api import cadastrar


def cadastro(page, alert, go_login):

    nome = ft.TextField(
        label="Nome",
        hint_text="Digite seu nome completo",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.PERSON
    )

    email = ft.TextField(
        label="Email",
        hint_text="Digite seu email",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.EMAIL,
        keyboard_type=ft.KeyboardType.EMAIL
    )

    senha = ft.TextField(
        label="Senha",
        hint_text="Mínimo 6 caracteres",
        password=True,
        can_reveal_password=True,
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.LOCK
    )

    confirmar_senha = ft.TextField(
        label="Confirmar senha",
        hint_text="Digite a senha novamente",
        password=True,
        can_reveal_password=True,
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.LOCK_RESET
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_cadastrar = ft.ElevatedButton(
        "Criar conta",
        width=320,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.APP_REGISTRATION
    )

    def email_valido(valor):
        valor = (valor or "").strip()
        return re.match(r"^[^@]+@[^@]+\.[^@]+$", valor)

    def set_loading(state):
        loading.visible = state
        btn_cadastrar.disabled = state
        btn_cadastrar.text = "Criando..." if state else "Criar conta"
        page.update()

    def salvar(e=None):
        status.value = ""

        nome_valor = (nome.value or "").strip()
        email_valor = (email.value or "").strip().lower()
        senha_valor = senha.value or ""
        confirmar_valor = confirmar_senha.value or ""

        if not nome_valor or not email_valor or not senha_valor or not confirmar_valor:
            status.value = "Preencha todos os campos"
            page.update()
            return

        if len(nome_valor) < 3:
            status.value = "Nome muito curto"
            page.update()
            return

        if not email_valido(email_valor):
            status.value = "Email inválido"
            page.update()
            return

        if len(senha_valor) < 6:
            status.value = "Senha deve ter no mínimo 6 caracteres"
            page.update()
            return

        if senha_valor != confirmar_valor:
            status.value = "As senhas não conferem"
            page.update()
            return

        set_loading(True)

        try:
            ok = cadastrar(nome_valor, email_valor, senha_valor)

            if ok:
                alert("Conta criada com sucesso!")
                go_login()
                return

            status.value = "Email já cadastrado ou erro ao criar conta"

        except Exception:
            status.value = "Erro ao conectar com o servidor"

        set_loading(False)

    senha.on_submit = salvar
    confirmar_senha.on_submit = salvar
    btn_cadastrar.on_click = salvar

    card = ft.Container(
        width=365,
        padding=30,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                ft.Container(
                    width=70,
                    height=70,
                    border_radius=22,
                    bgcolor="#1e293b",
                    alignment=ft.Alignment(0, 0),
                    content=ft.Icon(
                        ft.Icons.APP_REGISTRATION,
                        size=40,
                        color="#6366f1"
                    )
                ),

                ft.Text(
                    "Criar Conta",
                    size=30,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    "Crie sua conta para começar na Apexia",
                    size=13,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Divider(),

                nome,
                email,
                senha,
                confirmar_senha,

                btn_cadastrar,
                loading,
                status,

                ft.Row(
                    [
                        ft.Text(
                            "Já tem conta?",
                            size=12,
                            color="#9ca3af"
                        ),
                        ft.TextButton(
                            "Entrar",
                            on_click=lambda e: go_login()
                        )
                    ],
                    alignment=ft.MainAxisAlignment.CENTER
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=14
        )
    )

    return ft.Container(
        content=card,
        alignment=ft.Alignment(0, 0),
        expand=True,
        bgcolor="#0f172a"
    )