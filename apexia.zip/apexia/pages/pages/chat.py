import flet as ft
from api import enviar_mensagem, get_mensagens
from ui.layout import layout


def chat_page(page, router, user, alert):

    outro_id = ft.TextField(
        label="ID do usuário",
        hint_text="Digite o ID do usuário",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.PERSON,
        keyboard_type=ft.KeyboardType.NUMBER
    )

    mensagem = ft.TextField(
        label="Mensagem",
        hint_text="Digite sua mensagem...",
        width=275,
        border_radius=12,
        multiline=True,
        min_lines=1,
        max_lines=3,
        prefix_icon=ft.Icons.MESSAGE
    )

    lista = ft.Column(
        spacing=8,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_enviar = ft.IconButton(
        icon=ft.Icons.SEND,
        icon_color="#6366f1",
        tooltip="Enviar"
    )

    def set_loading(state):
        loading.visible = state
        btn_enviar.disabled = state
        page.update()

    def bubble(mensagem_data):
        meu = str(mensagem_data.get("remetente_id")) == str(user["id"])

        return ft.Row(
            [
                ft.Container(
                    constraints=ft.BoxConstraints(max_width=280),
                    padding=12,
                    bgcolor="#6366f1" if meu else "#1f2937",
                    border_radius=ft.border_radius.only(
                        top_left=16,
                        top_right=16,
                        bottom_left=16 if meu else 4,
                        bottom_right=4 if meu else 16
                    ),
                    content=ft.Column(
                        [
                            ft.Text(
                                "Você" if meu else f"Usuário {mensagem_data.get('remetente_id')}",
                                size=11,
                                color="#e0e7ff" if meu else "#9ca3af"
                            ),
                            ft.Text(
                                mensagem_data.get("mensagem", ""),
                                color="white",
                                size=14
                            )
                        ],
                        spacing=3
                    )
                )
            ],
            alignment=ft.MainAxisAlignment.END if meu else ft.MainAxisAlignment.START
        )

    def carregar_conversa(e=None):
        lista.controls.clear()
        status.value = ""

        alvo = (outro_id.value or "").strip()

        if not alvo:
            status.value = "Digite o ID do usuário"
            page.update()
            return

        loading.visible = True
        page.update()

        try:
            dados = get_mensagens(user["id"], alvo)
            loading.visible = False

            if not dados:
                lista.controls.append(
                    ft.Container(
                        width=350,
                        padding=24,
                        bgcolor="#111827",
                        border_radius=18,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.CHAT_BUBBLE_OUTLINE,
                                    size=46,
                                    color="#6366f1"
                                ),
                                ft.Text(
                                    "Nenhuma mensagem ainda",
                                    size=18,
                                    weight="bold",
                                    color="white"
                                ),
                                ft.Text(
                                    "Envie a primeira mensagem para iniciar a conversa.",
                                    size=12,
                                    color="#9ca3af",
                                    text_align=ft.TextAlign.CENTER
                                )
                            ],
                            spacing=10,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        )
                    )
                )
            else:
                for m in dados:
                    lista.controls.append(bubble(m))

        except Exception as erro:
            loading.visible = False
            status.value = f"Erro ao carregar conversa: {erro}"

        page.update()

    def enviar(e=None):
        status.value = ""

        alvo = (outro_id.value or "").strip()
        msg = (mensagem.value or "").strip()

        if not alvo:
            status.value = "Digite o ID do usuário"
            page.update()
            return

        if not msg:
            status.value = "Digite uma mensagem"
            page.update()
            return

        set_loading(True)

        try:
            ok = enviar_mensagem(
                user["id"],
                alvo,
                msg
            )

            if ok:
                mensagem.value = ""
                carregar_conversa()
                return

            status.value = "Erro ao enviar mensagem"

        except Exception:
            status.value = "Erro ao conectar com servidor"

        set_loading(False)

    outro_id.on_submit = carregar_conversa
    mensagem.on_submit = enviar
    btn_enviar.on_click = enviar

    input_bar = ft.Container(
        width=360,
        padding=10,
        bgcolor="#111827",
        border_radius=18,
        content=ft.Row(
            [
                mensagem,
                btn_enviar
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["home"]()
                    ),

                    ft.Column(
                        [
                            ft.Text(
                                "Chat",
                                size=28,
                                weight="bold",
                                color="white"
                            ),
                            ft.Text(
                                "Converse com outros usuários",
                                size=12,
                                color="#9ca3af"
                            )
                        ],
                        spacing=2
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            ft.Container(
                width=360,
                padding=14,
                bgcolor="#111827",
                border_radius=18,
                content=ft.Column(
                    [
                        outro_id,

                        ft.ElevatedButton(
                            "Carregar conversa",
                            width=320,
                            bgcolor="#6366f1",
                            color="white",
                            icon=ft.Icons.REFRESH,
                            on_click=carregar_conversa
                        )
                    ],
                    spacing=10,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                )
            ),

            ft.Row(
                [loading],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            status,

            ft.Container(
                width=360,
                padding=10,
                bgcolor="#020617",
                border_radius=18,
                content=lista
            ),

            input_bar
        ],
        spacing=15,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)