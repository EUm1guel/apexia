import flet as ft
from api import avaliar_curso, get_avaliacoes
from ui.layout import layout


def avaliacoes_page(page, router, user, curso_id, alert):

    nota = ft.Dropdown(
        label="Nota",
        width=320,
        border_radius=12,
        options=[
            ft.dropdown.Option("1"),
            ft.dropdown.Option("2"),
            ft.dropdown.Option("3"),
            ft.dropdown.Option("4"),
            ft.dropdown.Option("5"),
        ]
    )

    comentario = ft.TextField(
        label="Comentário",
        hint_text="Conte sua experiência com o curso",
        width=320,
        border_radius=12,
        multiline=True,
        min_lines=2,
        max_lines=4,
        prefix_icon=ft.Icons.RATE_REVIEW
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    lista = ft.Column(
        spacing=12,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    btn_enviar = ft.ElevatedButton(
        "Enviar avaliação",
        width=320,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.STAR
    )

    def estrelas(qtd):
        try:
            qtd = int(qtd or 0)
        except Exception:
            qtd = 0

        qtd = max(0, min(qtd, 5))
        return "⭐" * qtd + "☆" * (5 - qtd)

    def set_loading(state):
        loading.visible = state
        btn_enviar.disabled = state
        btn_enviar.text = "Enviando..." if state else "Enviar avaliação"
        page.update()

    def avaliacao_card(avaliacao):
        nota_valor = avaliacao.get("nota", 0)

        return ft.Container(
            width=360,
            padding=16,
            bgcolor="#111827",
            border_radius=18,
            shadow=ft.BoxShadow(
                blur_radius=12,
                color="#00000044",
                offset=ft.Offset(0, 4)
            ),
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.CircleAvatar(
                                radius=18,
                                bgcolor="#1e293b",
                                content=ft.Icon(
                                    ft.Icons.PERSON,
                                    size=18,
                                    color="#6366f1"
                                )
                            ),

                            ft.Column(
                                [
                                    ft.Text(
                                        f"Usuário {avaliacao.get('usuario_id', '')}",
                                        size=12,
                                        color="#9ca3af"
                                    ),
                                    ft.Text(
                                        estrelas(nota_valor),
                                        size=16,
                                        color="#facc15"
                                    )
                                ],
                                spacing=2,
                                expand=True
                            )
                        ],
                        spacing=10
                    ),

                    ft.Text(
                        avaliacao.get("comentario") or "Sem comentário",
                        color="#cbd5e1",
                        size=13
                    )
                ],
                spacing=10
            )
        )

    def carregar():
        lista.controls.clear()
        status.value = ""
        loading.visible = True
        page.update()

        try:
            dados = get_avaliacoes(curso_id)
            loading.visible = False

            if not dados:
                lista.controls.append(
                    ft.Container(
                        width=360,
                        padding=26,
                        bgcolor="#111827",
                        border_radius=20,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.STAR_BORDER,
                                    size=52,
                                    color="#6366f1"
                                ),
                                ft.Text(
                                    "Nenhuma avaliação ainda",
                                    size=20,
                                    weight="bold",
                                    color="white"
                                ),
                                ft.Text(
                                    "Seja o primeiro a avaliar este curso.",
                                    size=13,
                                    color="#9ca3af",
                                    text_align=ft.TextAlign.CENTER
                                )
                            ],
                            spacing=12,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        )
                    )
                )
            else:
                for avaliacao in dados:
                    lista.controls.append(
                        avaliacao_card(avaliacao)
                    )

        except Exception as erro:
            loading.visible = False
            status.value = f"Erro ao carregar avaliações: {erro}"

        page.update()

    def salvar(e=None):
        status.value = ""

        if not nota.value:
            status.value = "Escolha uma nota"
            page.update()
            return

        set_loading(True)

        try:
            ok = avaliar_curso(
                user["id"],
                curso_id,
                int(nota.value),
                comentario.value or ""
            )

            if ok:
                alert("Avaliação enviada!")
                comentario.value = ""
                nota.value = None
                carregar()
                return

            status.value = "Você já avaliou esse curso ou ocorreu erro"

        except Exception:
            status.value = "Erro ao conectar com servidor"

        set_loading(False)

    btn_enviar.on_click = salvar

    form_card = ft.Container(
        width=360,
        padding=20,
        bgcolor="#111827",
        border_radius=20,
        content=ft.Column(
            [
                ft.Text(
                    "Sua avaliação",
                    size=20,
                    weight="bold",
                    color="white"
                ),
                ft.Text(
                    "Avalie o curso e deixe um comentário.",
                    size=12,
                    color="#9ca3af"
                ),
                nota,
                comentario,
                btn_enviar,
                loading,
                status
            ],
            spacing=12,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    carregar()

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["cursos"]()
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                "Avaliações",
                                size=28,
                                weight="bold",
                                color="white"
                            ),
                            ft.Text(
                                "Veja opiniões e deixe sua nota",
                                size=12,
                                color="#9ca3af"
                            )
                        ],
                        spacing=2
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            form_card,

            ft.Divider(),

            ft.Text(
                "Avaliações recentes",
                size=18,
                weight="bold",
                color="white"
            ),

            lista
        ],
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=16
    )

    return layout(page, content, router)