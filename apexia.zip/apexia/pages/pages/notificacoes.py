import flet as ft
from api import get_notificacoes, marcar_notificacao_lida
from ui.layout import layout


def notificacoes_page(page, router, user, alert):

    lista = ft.Column(
        spacing=12,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    status = ft.Text("", color="#9ca3af", size=13)

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    def marcar_lida(notificacao_id):
        ok = marcar_notificacao_lida(notificacao_id)

        if ok:
            alert("Notificação marcada como lida")
            carregar()
        else:
            alert("Erro ao atualizar notificação")

    def card_notificacao(n):
        lida = n.get("lida", False)

        return ft.Container(
            width=360,
            padding=16,
            bgcolor="#111827" if not lida else "#0f172a",
            border_radius=18,
            border=ft.border.all(
                1,
                "#6366f1" if not lida else "#1e293b"
            ),
            shadow=ft.BoxShadow(
                blur_radius=12,
                color="#00000044",
                offset=ft.Offset(0, 4)
            ) if not lida else None,
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Container(
                                width=44,
                                height=44,
                                border_radius=14,
                                bgcolor="#1e293b",
                                alignment=ft.Alignment(0, 0),
                                content=ft.Icon(
                                    ft.Icons.NOTIFICATIONS,
                                    color="#6366f1",
                                    size=24
                                )
                            ),

                            ft.Column(
                                [
                                    ft.Text(
                                        n.get("titulo") or "Notificação",
                                        weight="bold",
                                        color="white",
                                        size=15
                                    ),
                                    ft.Text(
                                        "Não lida" if not lida else "Lida",
                                        size=11,
                                        color="#6366f1" if not lida else "#9ca3af"
                                    )
                                ],
                                spacing=2,
                                expand=True
                            )
                        ],
                        spacing=12,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER
                    ),

                    ft.Text(
                        n.get("mensagem") or "",
                        color="#cbd5e1",
                        size=13
                    ),

                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Marcar como lida",
                                bgcolor="#6366f1",
                                color="white",
                                disabled=lida,
                                on_click=lambda e, nid=n["id"]: marcar_lida(nid)
                            )
                        ],
                        alignment=ft.MainAxisAlignment.END
                    )
                ],
                spacing=10
            )
        )

    def carregar():
        lista.controls.clear()
        status.value = ""
        loading.visible = True
        page.update()

        try:
            dados = get_notificacoes(user["id"])
            loading.visible = False

            if not dados:
                lista.controls.append(
                    ft.Container(
                        width=360,
                        padding=28,
                        bgcolor="#111827",
                        border_radius=20,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.NOTIFICATIONS_NONE,
                                    size=52,
                                    color="#6366f1"
                                ),
                                ft.Text(
                                    "Nenhuma notificação",
                                    size=20,
                                    weight="bold",
                                    color="white"
                                ),
                                ft.Text(
                                    "Quando houver novidades, elas aparecerão aqui.",
                                    size=13,
                                    color="#9ca3af",
                                    text_align=ft.TextAlign.CENTER
                                )
                            ],
                            spacing=12,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        )
                    )
                )
            else:
                for n in dados:
                    lista.controls.append(card_notificacao(n))

        except Exception as erro:
            loading.visible = False
            status.value = f"Erro ao carregar notificações: {erro}"

        page.update()

    carregar()

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Notificações",
                                size=28,
                                weight="bold",
                                color="white"
                            ),
                            ft.Text(
                                "Acompanhe suas novidades na Apexia",
                                size=12,
                                color="#9ca3af"
                            )
                        ],
                        spacing=2
                    ),

                    ft.IconButton(
                        icon=ft.Icons.REFRESH,
                        icon_color="#6366f1",
                        tooltip="Atualizar",
                        on_click=lambda e: carregar()
                    )
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
            ),

            ft.Row([loading], alignment=ft.MainAxisAlignment.CENTER),

            status,

            lista
        ],
        spacing=16,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)
