import flet as ft
from api import get_dashboard
from ui.layout import layout


def admin_dashboard(page, router, user, alert):

    status = ft.Text("", color="#9ca3af", size=13)

    def carregar_dados():
        try:
            return get_dashboard() or {}
        except Exception as erro:
            status.value = f"Erro ao carregar dashboard: {erro}"
            return {}

    dados = carregar_dados()

    def card(titulo, valor, icon, cor="#6366f1"):
        return ft.Container(
            width=165,
            padding=18,
            bgcolor="#111827",
            border_radius=20,
            shadow=ft.BoxShadow(
                blur_radius=12,
                color="#00000044",
                offset=ft.Offset(0, 4)
            ),
            content=ft.Column(
                [
                    ft.Container(
                        width=50,
                        height=50,
                        border_radius=16,
                        bgcolor="#1e293b",
                        alignment=ft.Alignment(0, 0),
                        content=ft.Icon(icon, color=cor, size=28)
                    ),
                    ft.Text(str(valor), size=28, weight="bold", color="white"),
                    ft.Text(titulo, size=12, color="#9ca3af")
                ],
                spacing=8,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER
            )
        )

    def atualizar(e=None):
        nonlocal dados
        dados = carregar_dados()
        page.controls.clear()
        page.add(admin_dashboard(page, router, user, alert))
        page.update()

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Dashboard Admin",
                                size=28,
                                weight="bold",
                                color="white"
                            ),
                            ft.Text(
                                "Visão geral da plataforma Apexia",
                                size=12,
                                color="#9ca3af"
                            )
                        ],
                        spacing=2
                    ),
                    ft.IconButton(
                        icon=ft.Icons.REFRESH,
                        icon_color="#6366f1",
                        tooltip="Atualizar",
                        on_click=atualizar
                    )
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
            ),

            status,

            ft.Row(
                [
                    card("Usuários", dados.get("total_usuarios", 0), ft.Icons.PERSON),
                    card("Cursos", dados.get("total_cursos", 0), ft.Icons.SCHOOL),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=12
            ),

            ft.Row(
                [
                    card("Inscrições", dados.get("total_inscricoes", 0), ft.Icons.HOW_TO_REG),
                    card("Favoritos", dados.get("total_favoritos", 0), ft.Icons.FAVORITE, "#ef4444"),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=12
            ),

            ft.Row(
                [
                    card("Seguidores", dados.get("total_seguidores", 0), ft.Icons.GROUP, "#22c55e"),
                    card("Avaliações", dados.get("total_avaliacoes", 0), ft.Icons.STAR, "#facc15"),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=12
            ),

            ft.Container(
                width=350,
                padding=18,
                bgcolor="#111827",
                border_radius=20,
                content=ft.Column(
                    [
                        ft.Text(
                            "Resumo",
                            size=20,
                            weight="bold",
                            color="white"
                        ),
                        ft.Text(
                            "Use este painel para acompanhar o crescimento da plataforma.",
                            size=13,
                            color="#9ca3af"
                        ),
                    ],
                    spacing=8
                )
            )
        ],
        spacing=18,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)