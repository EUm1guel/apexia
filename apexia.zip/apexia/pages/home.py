import flet as ft
from ui.layout import layout


def home_view(page, router):

    def ir(rota):
        if rota in router:
            router[rota]()

    def action_card(icon, titulo, descricao, rota, cor="#6366f1"):
        return ft.Container(
            width=165,
            padding=16,
            border_radius=18,
            bgcolor="#111827",
            ink=True,
            on_click=lambda e: ir(rota),
            content=ft.Column(
                [
                    ft.Container(
                        width=46,
                        height=46,
                        border_radius=14,
                        bgcolor="#1e293b",
                        alignment=ft.Alignment(0, 0),
                        content=ft.Icon(icon, size=26, color=cor)
                    ),
                    ft.Text(titulo, size=14, weight="bold", color="white"),
                    ft.Text(
                        descricao,
                        size=11,
                        color="#9ca3af",
                        text_align=ft.TextAlign.CENTER
                    ),
                ],
                spacing=8,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER
            )
        )

    hero = ft.Container(
        width=360,
        padding=28,
        border_radius=24,
        bgcolor="#111827",
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                ft.Container(
                    width=72,
                    height=72,
                    border_radius=22,
                    bgcolor="#1e293b",
                    alignment=ft.Alignment(0, 0),
                    content=ft.Icon(
                        ft.Icons.AUTO_AWESOME,
                        size=42,
                        color="#6366f1"
                    )
                ),

                ft.Text(
                    "APEXIA",
                    size=42,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    "Aprenda, ensine e evolua com uma plataforma moderna.",
                    size=14,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Row(
                    [
                        ft.ElevatedButton(
                            "Explorar",
                            icon=ft.Icons.SCHOOL,
                            bgcolor="#6366f1",
                            color="white",
                            on_click=lambda e: ir("cursos")
                        ),
                        ft.OutlinedButton(
                            "Criar Curso",
                            icon=ft.Icons.ADD,
                            on_click=lambda e: ir("criar_curso")
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10
                )
            ],
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    stats = ft.Container(
        width=360,
        padding=18,
        border_radius=20,
        bgcolor="#111827",
        content=ft.Row(
            [
                ft.Column(
                    [
                        ft.Text("Cursos", size=12, color="#9ca3af"),
                        ft.Text("Online", size=18, weight="bold", color="white"),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                ft.Column(
                    [
                        ft.Text("Perfil", size=12, color="#9ca3af"),
                        ft.Text("Social", size=18, weight="bold", color="white"),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                ft.Column(
                    [
                        ft.Text("Conexões", size=12, color="#9ca3af"),
                        ft.Text("QR Code", size=18, weight="bold", color="white"),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_AROUND
        )
    )

    features = ft.Column(
        [
            ft.Row(
                [
                    ft.Text(
                        "Ações rápidas",
                        size=22,
                        weight="bold",
                        color="white"
                    ),
                    ft.Icon(ft.Icons.FLASH_ON, color="#f59e0b")
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=6
            ),

            ft.Row(
                [
                    action_card(
                        ft.Icons.SCHOOL,
                        "Cursos",
                        "Explore cursos disponíveis",
                        "cursos"
                    ),
                    action_card(
                        ft.Icons.ADD_BOX,
                        "Criar",
                        "Publique seu próprio curso",
                        "criar_curso"
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=14
            ),

            ft.Row(
                [
                    action_card(
                        ft.Icons.PERSON,
                        "Perfil",
                        "Edite stories, feed e bio",
                        "profile",
                        "#ec4899"
                    ),
                    action_card(
                        ft.Icons.QR_CODE,
                        "QR Code",
                        "Conecte-se com usuários",
                        "qr",
                        "#22c55e"
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=14
            ),
        ],
        spacing=16,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    content = ft.Column(
        [
            hero,
            stats,
            features
        ],
        spacing=24,
        alignment=ft.MainAxisAlignment.START,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        scroll=ft.ScrollMode.AUTO
    )

    return layout(page, content, router)