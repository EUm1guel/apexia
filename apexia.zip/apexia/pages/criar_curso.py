import flet as ft
from api import criar_curso as criar_curso_api
from ui.layout import layout


def criar_curso(page, router, alert, user):

    nome = ft.TextField(
        label="Nome do curso",
        hint_text="Ex: Python para iniciantes",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.SCHOOL
    )

    carga = ft.TextField(
        label="Carga horária",
        hint_text="Ex: 40 horas",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.TIMER
    )

    categoria = ft.Dropdown(
        label="Categoria",
        width=320,
        border_radius=12,
        value="Tecnologia",
        options=[
            ft.dropdown.Option("Tecnologia"),
            ft.dropdown.Option("Design"),
            ft.dropdown.Option("Negócios"),
            ft.dropdown.Option("Idiomas"),
            ft.dropdown.Option("Marketing"),
            ft.dropdown.Option("Outro"),
        ]
    )

    disciplinas = ft.TextField(
        label="Disciplinas / conteúdo",
        hint_text="Liste os principais tópicos do curso",
        width=320,
        multiline=True,
        min_lines=2,
        max_lines=4,
        border_radius=12,
        prefix_icon=ft.Icons.MENU_BOOK
    )

    imagem = ft.TextField(
        label="URL da imagem de capa",
        hint_text="https://...",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.IMAGE
    )

    descricao = ft.TextField(
        label="Descrição do curso",
        hint_text="Explique o que o aluno vai aprender",
        width=320,
        multiline=True,
        min_lines=3,
        max_lines=5,
        border_radius=12,
        prefix_icon=ft.Icons.DESCRIPTION
    )

    preview = ft.Image(
        src="https://placehold.co/600x300?text=Capa+do+curso",
        width=320,
        height=170,
        fit="cover",
        border_radius=14
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn = ft.ElevatedButton(
        "Publicar curso",
        width=320,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.PUBLISH
    )

    def atualizar_preview(e=None):
        url = (imagem.value or "").strip()

        if url.startswith("http"):
            preview.src = url
        else:
            preview.src = "https://placehold.co/600x300?text=Capa+do+curso"

        page.update()

    imagem.on_change = atualizar_preview

    def set_loading(state):
        loading.visible = state
        btn.disabled = state
        btn.text = "Publicando..." if state else "Publicar curso"
        page.update()

    def validar():
        nome_valor = (nome.value or "").strip()
        imagem_valor = (imagem.value or "").strip()
        descricao_valor = (descricao.value or "").strip()
        disciplinas_valor = (disciplinas.value or "").strip()

        if not nome_valor:
            return "Nome obrigatório"

        if len(nome_valor) < 3:
            return "Nome muito curto"

        if not descricao_valor:
            return "Descrição obrigatória"

        if not disciplinas_valor:
            return "Informe pelo menos uma disciplina"

        if not imagem_valor:
            return "Imagem de capa obrigatória"

        if not imagem_valor.startswith("http"):
            return "Use uma URL válida começando com http"

        return None

    def limpar_campos():
        nome.value = ""
        carga.value = ""
        disciplinas.value = ""
        imagem.value = ""
        descricao.value = ""
        categoria.value = "Tecnologia"
        preview.src = "https://placehold.co/600x300?text=Capa+do+curso"

    def salvar(e=None):
        erro = validar()

        if erro:
            status.value = erro
            page.update()
            return

        set_loading(True)
        status.value = ""

        try:
            data = {
                "nome": nome.value.strip(),
                "descricao": descricao.value.strip(),
                "carga_horaria": carga.value or "",
                "disciplinas": disciplinas.value or "",
                "imagem": imagem.value.strip(),
                "categoria": categoria.value or "Outro",
                "criador_id": user["id"]
            }

            ok = criar_curso_api(data)

            if ok:
                limpar_campos()
                alert("Curso criado com sucesso!")
                router["cursos"]()
                return

            status.value = "Erro ao criar curso"

        except Exception as erro:
            status.value = f"Erro ao conectar com servidor: {erro}"

        set_loading(False)

    btn.on_click = salvar

    card = ft.Container(
        width=365,
        padding=28,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                ft.Container(
                    width=70,
                    height=70,
                    border_radius=22,
                    bgcolor="#1e293b",
                    alignment=ft.Alignment(0, 0),
                    content=ft.Icon(
                        ft.Icons.ADD_CIRCLE,
                        size=40,
                        color="#6366f1"
                    )
                ),

                ft.Text(
                    "Criar Curso",
                    size=28,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    "Publique um curso completo para outros usuários participarem.",
                    size=12,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Divider(),

                nome,
                descricao,
                carga,
                categoria,
                disciplinas,
                imagem,

                ft.Text(
                    "Prévia da capa",
                    size=12,
                    color="#9ca3af"
                ),

                preview,

                btn,
                loading,
                status
            ],
            spacing=15,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["cursos"]()
                    ),
                    ft.Text(
                        "Novo curso",
                        size=28,
                        weight="bold",
                        color="white"
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            card
        ],
        spacing=20,
        scroll=ft.ScrollMode.AUTO,
        expand=True,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)