import flet as ft
import re

from api import criar_inscricao
from ui.layout import layout


def inscricao_form(page, router, user, curso_id, alert):

    # =========================
    # CAMPOS
    # =========================
    nome = ft.TextField(
        label="Nome completo",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.PERSON
    )

    cpf = ft.TextField(
        label="CPF",
        width=320,
        border_radius=12,
        prefix_icon=ft.Icons.BADGE,
        max_length=14
    )

    horario = ft.Dropdown(
        label="Horário desejado",
        width=320,
        border_radius=12,
        options=[
            ft.dropdown.Option("Manhã"),
            ft.dropdown.Option("Tarde"),
            ft.dropdown.Option("Noite"),
            ft.dropdown.Option("Integral"),
        ]
    )

    status = ft.Text(
        "",
        color="#ef4444",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_confirmar = ft.ElevatedButton(
        "Confirmar inscrição",
        width=320,
        height=46,
        bgcolor="#6366f1",
        color="white",
        icon=ft.Icons.CHECK
    )

    # =========================
    # FORMATAR CPF
    # =========================
    def formatar_cpf(e):

        valor = re.sub(
            r"\D",
            "",
            cpf.value or ""
        )

        if len(valor) > 11:
            valor = valor[:11]

        if len(valor) > 9:
            valor = (
                f"{valor[:3]}."
                f"{valor[3:6]}."
                f"{valor[6:9]}-"
                f"{valor[9:]}"
            )

        elif len(valor) > 6:
            valor = (
                f"{valor[:3]}."
                f"{valor[3:6]}."
                f"{valor[6:]}"
            )

        elif len(valor) > 3:
            valor = (
                f"{valor[:3]}."
                f"{valor[3:]}"
            )

        cpf.value = valor

        page.update()

    cpf.on_change = formatar_cpf

    # =========================
    # VALIDAR CPF
    # =========================
    def validar_cpf(cpf_val):

        cpf_val = re.sub(
            r"\D",
            "",
            cpf_val or ""
        )

        if (
            len(cpf_val) != 11
            or cpf_val == cpf_val[0] * 11
        ):
            return False

        soma = sum(
            int(cpf_val[i]) * (10 - i)
            for i in range(9)
        )

        d1 = (soma * 10 % 11) % 10

        soma = sum(
            int(cpf_val[i]) * (11 - i)
            for i in range(10)
        )

        d2 = (soma * 10 % 11) % 10

        return cpf_val[-2:] == f"{d1}{d2}"

    # =========================
    # LOADING
    # =========================
    def set_loading(state):

        loading.visible = state

        btn_confirmar.disabled = state

        btn_confirmar.text = (
            "Enviando..."
            if state
            else "Confirmar inscrição"
        )

        page.update()

    # =========================
    # SALVAR
    # =========================
    def salvar(e=None):

        status.value = ""

        nome_valor = (
            nome.value or ""
        ).strip()

        cpf_limpo = re.sub(
            r"\D",
            "",
            cpf.value or ""
        )

        horario_valor = (
            horario.value or ""
        ).strip()

        # =========================
        # VALIDAÇÕES
        # =========================
        if (
            not nome_valor
            or not cpf_limpo
            or not horario_valor
        ):

            status.value = (
                "Preencha todos os campos"
            )

            page.update()
            return

        if len(nome_valor) < 3:

            status.value = (
                "Nome muito curto"
            )

            page.update()
            return

        if not validar_cpf(cpf_limpo):

            status.value = (
                "CPF inválido"
            )

            page.update()
            return

        # =========================
        # REQUEST
        # =========================
        set_loading(True)

        try:

            ok = criar_inscricao(
                user["id"],
                curso_id,
                nome_valor,
                cpf_limpo,
                horario_valor
            )

            if ok:

                alert(
                    "Inscrição realizada com sucesso!"
                )

                router["profile"]()
                return

            status.value = (
                "Você já está inscrito "
                "ou ocorreu um erro"
            )

        except Exception as erro:

            status.value = (
                f"Erro ao conectar: {erro}"
            )

        set_loading(False)

    btn_confirmar.on_click = salvar

    # =========================
    # CARD
    # =========================
    card = ft.Container(
        width=360,
        padding=30,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 5)
        ),
        content=ft.Column(
            [
                ft.Icon(
                    ft.Icons.HOW_TO_REG,
                    size=46,
                    color="#6366f1"
                ),

                ft.Text(
                    "Inscrição no Curso",
                    size=28,
                    weight="bold",
                    color="white"
                ),

                ft.Text(
                    (
                        "Preencha seus dados "
                        "para participar."
                    ),
                    size=12,
                    color="#9ca3af",
                    text_align=ft.TextAlign.CENTER
                ),

                ft.Divider(),

                nome,
                cpf,
                horario,

                btn_confirmar,

                loading,

                status
            ],
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    # =========================
    # CONTENT
    # =========================
    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["cursos"]()
                    ),

                    ft.Text(
                        "Inscrição",
                        size=26,
                        weight="bold",
                        color="white"
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            card
        ],
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=18
    )

    return layout(
        page,
        content,
        router
    )