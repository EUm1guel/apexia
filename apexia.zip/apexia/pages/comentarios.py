import flet as ft
from api import request
from ui.layout import layout


def comentarios_page(page, router, user, post_id, alert):

    texto = ft.TextField(
        width=300,
        label="Escreva um comentário",
        border_radius=12,
        multiline=True,
        min_lines=1,
        max_lines=3,
        prefix_icon=ft.Icons.CHAT_BUBBLE_OUTLINE
    )

    lista = ft.Column(
        spacing=12,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    status = ft.Text(
        "",
        color="#9ca3af",
        size=13,
        text_align=ft.TextAlign.CENTER
    )

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_enviar = ft.IconButton(
        icon=ft.Icons.SEND,
        icon_color="#6366f1",
        tooltip="Enviar comentário"
    )

    def set_loading(state):
        loading.visible = state
        btn_enviar.disabled = state
        page.update()

    def comentario_card(comentario):
        return ft.Container(
            width=350,
            padding=14,
            bgcolor="#111827",
            border_radius=16,
            content=ft.Row(
                [
                    ft.CircleAvatar(
                        radius=18,
                        bgcolor="#1e293b",
                        content=ft.Icon(
                            ft.Icons.PERSON,
                            color="#6366f1",
                            size=18
                        )
                    ),

                    ft.Column(
                        [
                            ft.Text(
                                f"Usuário {comentario.get('usuario_id', '')}",
                                size=12,
                                color="#9ca3af"
                            ),

                            ft.Text(
                                comentario.get("comentario", ""),
                                size=14,
                                color="white"
                            ),
                        ],
                        spacing=3,
                        expand=True
                    )
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.START
            )
        )

    def carregar():
        lista.controls.clear()
        status.value = ""
        loading.visible = True
        page.update()

        try:
            r = request(
                "GET",
                f"comentarios?post_id=eq.{post_id}&order=criado_em.asc"
            )

            loading.visible = False

            if not r:
                status.value = "Erro ao carregar comentários"
                page.update()
                return

            comentarios = r.json()

            if not comentarios:
                lista.controls.append(
                    ft.Container(
                        width=350,
                        padding=24,
                        bgcolor="#111827",
                        border_radius=18,
                        content=ft.Column(
                            [
                                ft.Icon(
                                    ft.Icons.CHAT_BUBBLE_OUTLINE,
                                    size=42,
                                    color="#6366f1"
                                ),
                                ft.Text(
                                    "Nenhum comentário ainda",
                                    size=18,
                                    weight="bold",
                                    color="white"
                                ),
                                ft.Text(
                                    "Seja o primeiro a comentar neste post.",
                                    size=12,
                                    color="#9ca3af",
                                    text_align=ft.TextAlign.CENTER
                                )
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=10
                        )
                    )
                )
            else:
                for c in comentarios:
                    lista.controls.append(
                        comentario_card(c)
                    )

        except Exception as erro:
            loading.visible = False
            status.value = f"Erro: {erro}"

        page.update()

    def enviar(e=None):
        status.value = ""

        comentario_valor = (texto.value or "").strip()

        if not comentario_valor:
            status.value = "Digite um comentário"
            page.update()
            return

        set_loading(True)

        try:
            r = request(
                "POST",
                "comentarios",
                json={
                    "post_id": post_id,
                    "usuario_id": user["id"],
                    "comentario": comentario_valor
                }
            )

            if r and r.status_code in [200, 201]:
                texto.value = ""
                alert("Comentário enviado!")
                carregar()
                return

            status.value = "Erro ao enviar comentário"

        except Exception:
            status.value = "Erro ao conectar com servidor"

        set_loading(False)

    texto.on_submit = enviar
    btn_enviar.on_click = enviar

    carregar()

    input_bar = ft.Container(
        width=360,
        padding=10,
        bgcolor="#111827",
        border_radius=18,
        content=ft.Row(
            [
                texto,
                btn_enviar
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["feed"]()
                    ),

                    ft.Text(
                        "Comentários",
                        size=28,
                        weight="bold",
                        color="white"
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            ft.Row(
                [loading],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            status,
            lista,
            input_bar
        ],
        spacing=16,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)