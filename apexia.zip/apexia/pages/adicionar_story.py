import flet as ft
from api import criar_story
from ui.layout import layout


def adicionar_story(page, router, user, alert):

    if "_stories" not in user:
        user["_stories"] = []

    titulo = ft.TextField(
        label="Título do story",
        width=330,
        border_radius=12,
        prefix_icon=ft.Icons.TEXT_FIELDS
    )

    legenda = ft.TextField(
        label="Legenda",
        width=330,
        border_radius=12,
        multiline=True,
        min_lines=2,
        max_lines=4,
        prefix_icon=ft.Icons.EDIT
    )

    url_midia = ft.TextField(
        label="URL da imagem ou vídeo",
        hint_text="https://...",
        width=330,
        border_radius=12,
        prefix_icon=ft.Icons.LINK
    )

    preview = ft.Container(
        width=330,
        height=480,
        bgcolor="#111827",
        border_radius=25,
        alignment=ft.Alignment(0, 0),
        content=ft.Column(
            [
                ft.Icon(ft.Icons.ADD_A_PHOTO, size=60, color="#9ca3af"),
                ft.Text("Cole a URL da imagem ou vídeo", color="#9ca3af")
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    status = ft.Text("", color="#ef4444", size=12)

    loading = ft.ProgressRing(
        visible=False,
        width=22,
        height=22
    )

    btn_publicar = ft.ElevatedButton(
        "Publicar story",
        width=330,
        height=46,
        bgcolor="#ec4899",
        color="white",
        icon=ft.Icons.SEND
    )

    def eh_video(url):
        url = (url or "").lower()
        return url.endswith((".mp4", ".webm", ".mov"))

    def atualizar_preview(e=None):
        url = (url_midia.value or "").strip()

        if not url:
            preview.content = ft.Column(
                [
                    ft.Icon(ft.Icons.ADD_A_PHOTO, size=60, color="#9ca3af"),
                    ft.Text("Cole a URL da imagem ou vídeo", color="#9ca3af")
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER
            )

        elif eh_video(url):
            preview.content = ft.Column(
                [
                    ft.Icon(ft.Icons.VIDEOCAM, size=70, color="white"),
                    ft.Text("Vídeo adicionado", color="white"),
                    ft.Text(url, size=10, color="#9ca3af", width=280)
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER
            )

        else:
            preview.content = ft.Image(
                src=url,
                width=330,
                height=480,
                fit="cover",
                border_radius=25
            )

        page.update()

    url_midia.on_change = atualizar_preview

    def set_loading(state):
        loading.visible = state
        btn_publicar.disabled = state
        btn_publicar.text = "Publicando..." if state else "Publicar story"
        page.update()

    def publicar(e=None):
        status.value = ""

        titulo_valor = (titulo.value or "").strip()
        legenda_valor = (legenda.value or "").strip()
        midia_url = (url_midia.value or "").strip()

        if not titulo_valor:
            status.value = "Digite um título"
            page.update()
            return

        if not midia_url:
            status.value = "Cole a URL da imagem ou vídeo"
            page.update()
            return

        if not midia_url.startswith("http"):
            status.value = "Use uma URL válida começando com http"
            page.update()
            return

        set_loading(True)

        try:
            tipo = "video" if eh_video(midia_url) else "imagem"

            user["_stories"].append({
                "titulo": titulo_valor,
                "midia": midia_url,
                "img": midia_url,
                "tipo": tipo,
                "legenda": legenda_valor,
                "texto": legenda_valor
            })

            try:
                criar_story(
                    user["id"],
                    titulo_valor,
                    midia_url,
                    legenda_valor,
                    tipo
                )
            except Exception:
                pass

            alert("Story publicado!")
            router["perfil"]()
            return

        except Exception as erro:
            status.value = f"Erro ao publicar story: {erro}"

        set_loading(False)

    btn_publicar.on_click = publicar

    card = ft.Container(
        width=365,
        padding=24,
        bgcolor="#111827",
        border_radius=24,
        shadow=ft.BoxShadow(
            blur_radius=18,
            color="#00000055",
            offset=ft.Offset(0, 6)
        ),
        content=ft.Column(
            [
                preview,

                titulo,
                legenda,
                url_midia,

                btn_publicar,
                loading,
                status,
            ],
            spacing=14,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    content = ft.Column(
        [
            ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK,
                        icon_color="white",
                        on_click=lambda e: router["perfil"]()
                    ),
                    ft.Text(
                        "Novo story",
                        size=28,
                        weight="bold",
                        color="white"
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            ft.Text(
                "Cole a URL de uma imagem ou vídeo para criar seu story.",
                size=13,
                color="#9ca3af",
                text_align=ft.TextAlign.CENTER
            ),

            card
        ],
        spacing=18,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    return layout(page, content, router)