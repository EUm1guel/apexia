import flet as ft


def curso_view(page, curso, go_home):

    def info_item(icon, titulo, valor):
        return ft.Row(
            [
                ft.Icon(icon, color="#6366f1", size=22),
                ft.Column(
                    [
                        ft.Text(titulo, size=12, color="#9ca3af"),
                        ft.Text(str(valor), size=15, weight="bold", color="white"),
                    ],
                    spacing=2
                )
            ],
            spacing=12
        )

    return ft.Container(
        expand=True,
        bgcolor="#0f172a",
        padding=20,
        content=ft.Column(
            [
                ft.Text(
                    curso.get("nome", "Curso"),
                    size=25,
                    weight="bold",
                    color="white"
                ),

                ft.Image(
                    src=curso.get("imagem") or "https://placehold.co/600x300",
                    width=340,
                    height=200,
                    fit="cover",
                    border_radius=16
                ),

                ft.Text(
                    curso.get("descricao", "Sem descrição"),
                    size=14,
                    color="#d1d5db"
                ),

                ft.Container(
                    bgcolor="#111827",
                    border_radius=16,
                    padding=15,
                    content=ft.Column(
                        [
                            info_item(
                                ft.Icons.SCHEDULE,
                                "Carga horária",
                                curso.get("carga_horaria", "Não informado")
                            ),
                            info_item(
                                ft.Icons.MENU_BOOK,
                                "Disciplinas",
                                curso.get("disciplinas", "Não informado")
                            ),
                            info_item(
                                ft.Icons.PERSON,
                                "Professor",
                                curso.get("professor", "Não informado")
                            ),
                        ],
                        spacing=12
                    )
                ),

                ft.ElevatedButton(
                    "Voltar",
                    width=320,
                    bgcolor="#6366f1",
                    color="white",
                    on_click=lambda e: go_home()
                )
            ],
            spacing=16,
            scroll=ft.ScrollMode.AUTO,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )