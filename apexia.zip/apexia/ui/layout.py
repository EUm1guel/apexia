import flet as ft


def layout(page, content, router):

    def ir(rota):
        if rota in router:
            router[rota]()

    def btn(nome, rota, icon):
        ativo = (
            page.route == f"/{rota}"
            or (rota == "profile" and page.route == "/perfil")
            or (rota == "qr" and page.route == "/qr")
        )

        return ft.Container(
            padding=ft.padding.symmetric(horizontal=10, vertical=8),
            border_radius=12,
            bgcolor="#1e293b" if ativo else "transparent",
            ink=True,
            on_click=lambda e: ir(rota),
            content=ft.Row(
                [
                    ft.Icon(
                        icon,
                        size=18,
                        color="#818cf8" if ativo else "#cbd5e1"
                    ),
                    ft.Text(
                        nome,
                        size=13,
                        color="#818cf8" if ativo else "#cbd5e1",
                        weight="bold" if ativo else "normal"
                    )
                ],
                spacing=5
            )
        )

    navbar = ft.Container(
        bgcolor="#020617",
        padding=ft.padding.symmetric(horizontal=12, vertical=12),
        border=ft.border.only(
            bottom=ft.border.BorderSide(1, "#1e293b")
        ),
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Row(
                            [
                                ft.Icon(
                                    ft.Icons.AUTO_AWESOME,
                                    color="#6366f1",
                                    size=22
                                ),
                                ft.Text(
                                    "APEXIA",
                                    color="#6366f1",
                                    size=22,
                                    weight="bold"
                                ),
                            ],
                            spacing=6
                        ),

                        ft.Container(
                            padding=ft.padding.symmetric(horizontal=8, vertical=7),
                            border_radius=10,
                            ink=True,
                            on_click=lambda e: ir("logout"),
                            content=ft.Row(
                                [
                                    ft.Icon(
                                        ft.Icons.LOGOUT,
                                        color="#ef4444",
                                        size=17
                                    ),
                                    ft.Text(
                                        "Sair",
                                        color="#ef4444",
                                        size=13
                                    )
                                ],
                                spacing=4
                            )
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER
                ),

                ft.Row(
                    [
                        btn("Home", "home", ft.Icons.HOME),
                        btn("Cursos", "cursos", ft.Icons.SCHOOL),
                        btn("Perfil", "profile", ft.Icons.PERSON),
                        btn("QR", "qr", ft.Icons.QR_CODE),
                        btn("Loja", "loja", ft.Icons.STORE),
                    ],
                    spacing=6,
                    scroll=ft.ScrollMode.AUTO
                )
            ],
            spacing=10
        )
    )

    return ft.Container(
        expand=True,
        bgcolor="#0f172a",
        content=ft.Column(
            [
                navbar,
                ft.Container(
                    content=content,
                    expand=True,
                    padding=20
                )
            ],
            expand=True,
            spacing=0
        )
    )