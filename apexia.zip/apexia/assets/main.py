import flet as ft
import os
import webbrowser

from pages.login import login_view
from pages.cadastro import cadastro
from pages.home import home_view
from pages.perfil import perfil
from pages.inscricoes import inscricoes
from pages.cursos import cursos
from pages.inscricao_form import inscricao_form
from pages.criar_curso import criar_curso
from pages.qr_page import qr_page
from pages.editar_perfil import editar_perfil
from pages.adicionar_story import adicionar_story

from pages.feed import feed_page
from pages.comentarios import comentarios_page
from pages.aulas import aulas_page
from pages.pagamentos import pagamento_page

from pages.pages.chat import chat_page
from pages.pages.notificacoes import notificacoes_page
from pages.pages.avaliacoes import avaliacoes_page
from pages.pages.admin_dashboard import admin_dashboard


def main(page: ft.Page):

    page.title = "Apexia"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = "#0f172a"
    page.window_width = 400
    page.window_height = 800
    page.padding = 0
    page.spacing = 0
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.START

    state = {
        "user": None,
        "curso_id": None,
        "post_id": None,
    }

    def alert(msg):
        page.snack_bar = ft.SnackBar(
            content=ft.Text(msg, color="white"),
            bgcolor="#111827",
            duration=2500
        )
        page.snack_bar.open = True
        page.update()

    def get_user():
        return state["user"]

    def set_user(user):
        state["user"] = user

        if "_stories" not in state["user"]:
            state["user"]["_stories"] = []

        if "_feed" not in state["user"]:
            state["user"]["_feed"] = []

        go("/home")

    def logout():
        state["user"] = None
        state["curso_id"] = None
        state["post_id"] = None
        go("/")

    def go(route):
        page.route = route
        route_change(None)

    def abrir_inscricao(curso_id):
        state["curso_id"] = curso_id
        go("/inscricao_form")

    def abrir_avaliacoes(curso_id):
        state["curso_id"] = curso_id
        go("/avaliacoes")

    def abrir_aulas(curso_id):
        state["curso_id"] = curso_id
        go("/aulas")

    def abrir_pagamento(curso_id):
        state["curso_id"] = curso_id
        go("/pagamento")

    def abrir_comentarios(post_id):
        state["post_id"] = post_id
        go("/comentarios")

    def abrir_loja():
        caminho = os.path.abspath("assets/loja.html")

        if not os.path.exists(caminho):
            alert("Arquivo loja.html não encontrado dentro da pasta assets")
            return

        webbrowser.open(f"file:///{caminho.replace(os.sep, '/')}")

    def router():
        return {
            "loja": abrir_loja,

            "home": lambda: go("/home"),
            "login": lambda: go("/"),
            "cadastro": lambda: go("/cadastro"),

            "profile": lambda: go("/perfil"),
            "perfil": lambda: go("/perfil"),
            "editar_perfil": lambda: go("/editar_perfil"),
            "adicionar_story": lambda: go("/adicionar_story"),

            "cursos": lambda: go("/cursos"),
            "criar_curso": lambda: go("/criar_curso"),
            "insc": lambda: go("/inscricoes"),

            "qr": lambda: go("/qr"),
            "feed": lambda: go("/feed"),

            "chat": lambda: go("/chat"),
            "notificacoes": lambda: go("/notificacoes"),
            "admin": lambda: go("/admin"),

            "ir_inscricao": abrir_inscricao,
            "abrir_avaliacoes": abrir_avaliacoes,
            "abrir_aulas": abrir_aulas,
            "abrir_pagamento": abrir_pagamento,

            "comentarios": abrir_comentarios,
            "logout": logout,
        }

    def precisa_login():
        if not get_user():
            go("/")
            return True
        return False

    def route_change(e):
        page.controls.clear()

        user = get_user()
        r = router()

        if page.route == "/":
            page.add(login_view(page, go, set_user))

        elif page.route == "/cadastro":
            page.add(cadastro(page, alert, lambda: go("/")))

        elif page.route == "/home":
            if precisa_login():
                return
            page.add(home_view(page, r))

        elif page.route == "/perfil":
            if precisa_login():
                return
            page.add(perfil(page, r, user, alert))

        elif page.route == "/editar_perfil":
            if precisa_login():
                return
            page.add(editar_perfil(page, r, user, alert))

        elif page.route == "/adicionar_story":
            if precisa_login():
                return
            page.add(adicionar_story(page, r, user, alert))

        elif page.route == "/inscricoes":
            if precisa_login():
                return
            page.add(inscricoes(page, r, user, alert))

        elif page.route == "/cursos":
            if precisa_login():
                return
            page.add(cursos(page, r, user, alert))

        elif page.route == "/criar_curso":
            if precisa_login():
                return
            page.add(criar_curso(page, r, alert, user))

        elif page.route == "/inscricao_form":
            if precisa_login():
                return

            if not state["curso_id"]:
                alert("Selecione um curso primeiro")
                go("/cursos")
                return

            page.add(inscricao_form(page, r, user, state["curso_id"], alert))

        elif page.route == "/qr":
            if precisa_login():
                return
            page.add(qr_page(page, r, user, alert))

        elif page.route == "/feed":
            if precisa_login():
                return
            page.add(feed_page(page, r, user, alert))

        elif page.route == "/comentarios":
            if precisa_login():
                return

            if not state["post_id"]:
                alert("Selecione um post primeiro")
                go("/feed")
                return

            page.add(comentarios_page(page, r, user, state["post_id"], alert))

        elif page.route == "/aulas":
            if precisa_login():
                return

            if not state["curso_id"]:
                alert("Selecione um curso primeiro")
                go("/cursos")
                return

            page.add(aulas_page(page, r, user, state["curso_id"], alert))

        elif page.route == "/pagamento":
            if precisa_login():
                return

            if not state["curso_id"]:
                alert("Selecione um curso primeiro")
                go("/cursos")
                return

            page.add(pagamento_page(page, r, user, state["curso_id"], alert))

        elif page.route == "/avaliacoes":
            if precisa_login():
                return

            if not state["curso_id"]:
                alert("Selecione um curso primeiro")
                go("/cursos")
                return

            page.add(avaliacoes_page(page, r, user, state["curso_id"], alert))

        elif page.route == "/chat":
            if precisa_login():
                return
            page.add(chat_page(page, r, user, alert))

        elif page.route == "/notificacoes":
            if precisa_login():
                return
            page.add(notificacoes_page(page, r, user, alert))

        elif page.route == "/admin":
            if precisa_login():
                return
            page.add(admin_dashboard(page, r, user, alert))

        else:
            page.add(
                ft.Container(
                    expand=True,
                    alignment=ft.Alignment(0, 0),
                    content=ft.Column(
                        [
                            ft.Icon(ft.Icons.ERROR_OUTLINE, size=60, color="#ef4444"),
                            ft.Text(
                                "Página não encontrada",
                                size=24,
                                weight="bold",
                                color="white"
                            ),
                            ft.ElevatedButton(
                                "Voltar para Home",
                                bgcolor="#6366f1",
                                color="white",
                                on_click=lambda e: go("/home")
                            )
                        ],
                        spacing=15,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER
                    )
                )
            )

        page.update()

    page.on_route_change = route_change
    page.route = "/"
    route_change(None)


ft.app(
    target=main,
    assets_dir="assets"
)